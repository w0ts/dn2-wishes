"""v0.27: the frame-time guard (docs/sharc-load.md, "The frame-time guard").

The owner's v0.26 report: two PERC tracks p-locked with a sample track and an FM track
gave a loud click and then no audio at all until a reboot. Each of our voices runs inside
the SHARC's per-frame work (the per-block routine, after the stock machines), and an
exact Machinedrum voice costs up to about 40,000 instructions a block. If the frame's
work runs past the frame, the audio stops.

So before each of our voices the loop asks the core's cycle counter how far into the
frame it is, and plays the voice only if its expected cost still fits under a limit;
a voice that does not fit is silent for that block (its buffer zeroed, its state kept)
and counted. The time a frame has is measured: entry_mark.asm stores EMUCLK as the
handler calls the per-block routine (MARK0), once a frame, so the difference between
two frames' MARK0 is the frame's length in cycles; the limit is about 0.6 of it (the
stock work after our voices, the effects and the mix, took about 0.29 of a frame on the
instrument, docs/sharc-load.md). Each voice's own cost is measured too, around its
render, and the next block expects one and a half times it (at least FLOOR).

Emit only: the DSP code, not the model. The runner's EMUCLK does not move, so there the
guard always plays the voice (and the checks hold every voice to the model as before);
the runner's guard step feeds the clock to make it skip.
"""

from __future__ import annotations

MARK0 = 0x2DE13C                 # entry_mark.asm: EMUCLK as the handler calls the per-block routine
GUARD = 0x2DE000                 # free words between PERC's scratch (to 0x2ddfe8) and idle_load's state (0x2de100)
LIMIT = GUARD + 0x00             # cycles after MARK0 by which our voices must be done
PREV = GUARD + 0x04              # the last frame's MARK0
SKIPS = GUARD + 0x08             # voices left silent, cumulative
START = GUARD + 0x0C             # EMUCLK as the current voice began
PERIOD = GUARD + 0x10            # the last frame's length, cycles
COUNT = GUARD + 0x14             # the zeroing loop's counter
SKIPMASK = GUARD + 0x18          # v0.30: the slots skipped since the ColdFire last heard (bit t), sent and cleared by smp's idle packet
# v0.32: the limit from what the stock does after our voices, measured (the owner's dropouts
# with many voices: the fixed 0.6 of a frame assumed the stock's tail -- the voice chain,
# FX, mix -- took 0.29 of it, as measured with few voices; with sixteen it takes more)
TAIL = GUARD + 0x1C              # the stock's tail after our voices, cycles, held at its peak
PREV_AFTER = GUARD + 0x20        # idle_load's AFTER total at the last entry
PREV_MARK = GUARD + 0x24         # MARK (our entry, block_count.asm) at the last entry
OURS_END = GUARD + 0x28          # EMUCLK as our voices finished (smp.asm's tail)
METER_NOW = GUARD + 0x2C         # v0.32, the load meter: EMUCLK and the idle total at the
METER_IDLE = GUARD + 0x30        # last idle packet (dnfw.sampler.program)
AFTER = 0x2DE12C                 # idle_load.asm: AFTER, cumulative (MARK to the busy stretch's end)
MARK = 0x2DE124                  # block_count.asm: EMUCLK at our entry
IDLE_TOTAL = 0x2DE110            # idle_load.asm: the idle task's cycles, cumulative
COST_PERC = GUARD + 0x40         # 16 words: each PERC slot's last cost, cycles
COST_SMP = GUARD + 0x80          # 16 words: each sample slot's
# v0.34: the output guard's record (docs/timing-model.md): which voice went non-finite and
# where its memory first held a non-finite word, so the unit can say what poisons a voice
BLOWN_COUNT = GUARD + 0xC0       # voices wiped, cumulative
BLOWN_INFO = GUARD + 0xC4        # the last: slot | machine type << 8
BLOWN_WHERE = GUARD + 0xC8       # the last: WHERE_NONE, or the first non-finite word's index
BLOWN_WORD = GUARD + 0xCC        # that word's bits
BLOWN_MASK = GUARD + 0xD0        # bit t: slot t wiped since the ColdFire last heard (sent, then cleared)
# v0.49 (NiKo's report: an ONESHOT kick crunchy at ~85 % beside SID and three PERC voices): the
# sample voices' time is held back from PERC's, and a sample voice left out twice in a note stops
RESERVE = GUARD + 0xD4           # the sample voices' expected cost this block (sounding or triggered)
LIMIT_PERC = GUARD + 0xD8        # LIMIT less RESERVE: PERC's and the Monomachine's limit
STRUCK = GUARD + 0xDC            # bit t: sample slot t left out once in its current note
RES_I = GUARD + 0xE0             # perc_limit's loop counter
# 2026-11-09 (the User: PLAITS silent sequenced with voice rotation, CPU): a voice's start block
# (PLAITS' engine starting: a voice changing machine to PLAITS, or MODL) does its set-up work
# once; its cost is not what its next blocks cost. PLAITS sets FRESH in such a block (`fresh`), and
# `around` then keeps 0 as the slot's cost (the next block expected at FLOOR, then at what it
# measures), so one heavy start cannot get the note's next blocks refused twice and the note
# stolen. Only PLAITS sets it: every other machine's guard decisions are as before.
FRESH = GUARD + 0xE4                # (v0.52 merge: after v0.49's RESERVE .. RES_I)
# 2026-11-10 (the User: the inserts "should not affect voices"): the insert passes' time is measured
# apart (INS_ACC, the frame's; INS_LAST the last frame's) and taken out of the stock's tail, so it no
# longer lowers the voices' LIMIT; instead each insert runs in a block only if it is expected to end
# before INS_DEADLINE (cycles after MARK0: P - P/8 - TAIL, the end of the frame less the guard's margin
# and the stock's own tail), else it passes the sound through for that block (INS_SKIPS counts them)
INS_DEADLINE = GUARD + 0xE8
INS_ACC = GUARD + 0xEC
INS_T0 = GUARD + 0xF0
INS_SKIPS = GUARD + 0xF4
# 2026-11-20 (clip-inner; the User: "NO DIGITAL CLIPPING ... if it does, i want the alert"): a voice's own clip or
# limiter. CLIP_HIT: any word but 0 when a stage of the voice now running clipped this block (the stage stores
# its own nonzero constant; out_guard reads and clears it, a voice at a time); CLIPMASK: bit t, slot t clipped since
# the ColdFire last heard (sent in the clip packet, then cleared; dnfw.sampler.program tdm_tx)
CLIP_HIT = GUARD + 0xF8
CLIPMASK = GUARD + 0xFC
END = GUARD + 0x100
assert END <= 0x2DE100
# v0.52 merge: v0.49's four words filled the block, so the later insert words lie in the free words
# just below it, after PERC's scratch (90 words from 0x2dde80, to 0x2ddfe8; test_waverider_dsp checks)
INS_LO = GUARD - 0x10
INS_DLP = INS_LO + 0x00          # 2026-11-11: this pass's deadline (ins_start), 0 when none is known
INS_BUSEND = INS_LO + 0x04       # 2026-11-11: EMUCLK as the bus pass (the last insert pass) ended
REST_OUT = INS_LO + 0x08         # 2026-11-11: the stock's time after the bus pass (the output stage), held at its peak
INS_TESTCLK = INS_LO + 0x0C      # 2026-11-12: the model's stand-in for EMUCLK in ins_gate (the DSP never reads it)
INS_LO_END = INS_LO + 0x10
assert INS_LO_END <= GUARD
# 2026-11-20 (clip-inner): a clip of a stage that runs per track or per send, not inside a voice (the inserts, the
# A2 filter machines' pass by slot goes to CLIPMASK): bit t track t, bits 16..18 the send returns (DEL, REV, CHR);
# sent beside CLIPMASK in the clip packet, then cleared. In the two free words after PERC's scratch (0x2ddfe8)
CLIPTRK = INS_LO - 0x08
CLIPTRK_RET = 16                 # bit 16 + r: send return r (0 the delay)
# 2026-11-22 (the system meter's CUT, csrc/meter/skips.c): the voices the guard ended for time, cumulative: a voice
# stolen (it rests until its next note) or a sample voice stopped (left out twice in a note). The second of the two
# free words after PERC's scratch (CLIPTRK the first); whatever RAM held at power-on: the ColdFire counts its
# differences only. Sent as the idle packet's unit 42 (dnfw.sampler.program; it carried INS_TSKIP[0], type OFF,
# which nothing counts)
STEALS = INS_LO - 0x04


def count_steal(p) -> None:
    """STEALS + 1. Emit only. Clobbers R9, R10."""
    p.ld(9, STEALS)
    p.iconst(10, 1)
    p.iop(9, 9, "+", 10)
    p.st(STEALS, 9)
INS_HOLD = 64                    # 2026-11-12 (ins_gate): blocks an instance, once refused, must fit in a row to come back


# 2026-11-09 (the User's choice B): a PLAITS note's first START_BLOCKS blocks are expected at the
# machine's fixed start bound (dnfw.perc.program MNM_START, from MNM_COST), not at 1.5 x the slot's
# stored cost (another note's, a start block's: stale or inflated), and a refusal in its trig block
# is no strike (it is tried again; only refusals after it count towards the steal). The bounds sit
# 16 words after the keys block's BOUNDS_AFTER_KEYS (0 for every slot not on PLAITS: the other
# machines decide exactly as before).
START_BLOCKS = 2
BOUNDS_AFTER_KEYS = 0x180 // 4                 # program.BOUNDS_OFF - MNM_KEYS_OFF, in words

# 2026-11-10 (b6, the User's choice A + B after b5diag2's record on the unit: 15 PLAITS voices all
# rendering, each 20,000 .. 48,000 cycles, every one expected at FLOOR's 60,000):
# A. a PLAITS slot with a measured cost is expected at 1.5 x that cost, at least PLAITS_FLOOR, not
#    FLOOR (FLOOR is 1.5 x 40,000: a WS voice measures about 20,000). A cost of 0 (a start block,
#    FRESH: an engine just changed, its steady cost not known yet) is still expected at FLOOR.
# B. the pages' CPU flag (SKIPMASK) is set only when the refused PERC voice's note is new (its key's
#    age under NEW_NOTE_BLOCKS, ~100 ms): a ringing voice cut short (refused, then stolen) is counted
#    in SKIPS but no longer lights CPU, which is meant to say a note was not heard.
# 2026-11-10 (poly16): a PLAITS slot's next block is expected at its last cost + last >> 2 (1.25 x),
# not 1.5 x: its engines' blocks vary little (PART's worst, a diffuser half taking the old path,
# +18 %), and with 15 voices before it the 16th voice's 0.5 x margin was what the frame lacked (the
# runner's poly16: three voices refused a block, then stolen). LIMIT keeps P / 8 in reserve anyway.
PLAITS_SLACK_SHIFT = 2
PLAITS_FLOOR = 20_000                          # 2026-11-10 (poly16): 30,000 until then; every engine's
                                               # steady block now costs 10,000 .. 25,000, and the last of 16
                                               # voices needs 15 x cost + max(1.5 x cost, floor) to fit
NEW_NOTE_BLOCKS = 150                          # blocks of 32 samples: 100 ms at 48 kHz


def _key_and_bound(p, t_word: int, keys: int) -> None:
    """R10 = this slot's key (age x 16 + slot), R11 = its start bound. Clobbers R12, I5."""
    p.ld(10, t_word)
    p.lsh(10, 10, 2)
    p.iconst(12, keys)
    p.iop(10, 12, "+", 10)
    p.seti(5, 10)
    p.ldi(10, 0, 5)
    p.ldi(11, BOUNDS_AFTER_KEYS, 5)


def fresh(p, r: int = 12) -> None:
    """the voice code: this block is a voice's start (FRESH = 1). Clobbers Rr."""
    p.iconst(r, 1)
    p.st(FRESH, r)
WHERE_NONE = 0xFFFF              # the voice's delay lines held nothing non-finite (its state, input or effects did)
WHERE_DELAY = 0x8000             # | the first non-finite delay-line word's index (0..2047)
LIMIT_DEFAULT = 400_000          # until a frame has been measured: 0.6 of 666,667 (1 GHz, 1,500 frames a second)
FLOOR = 60_000                   # what a voice is expected to cost at least
PERIOD_MIN, PERIOD_MAX = 300_000, 3_000_000


def entry(p) -> None:
    """Once a frame, at PERC's entry: the frame's length, and the limit from it."""
    p.comment("v0.27: the frame's length (MARK0 - the last MARK0) and the limit, 0.6 of it")
    keep = p.label("gkeep")
    ok = p.label("gok")
    p.ld(8, MARK0)
    p.ld(9, PREV)
    p.st(PREV, 8)
    p.e("R9 = R8 - R9;", "the frame's length")
    p.iconst(10, PERIOD_MIN)
    p.e("COMP(R9, R10);")
    p.jump("LT", keep)
    p.iconst(10, PERIOD_MAX)
    p.e("COMP(R9, R10);")
    p.jump("GT", keep)
    p.st(PERIOD, 9)
    p.lsh(8, 9, -1)                            # 1/2 + 1/16 + 1/32 + 1/128 = 0.6016
    p.lsh(10, 9, -4)
    p.iop(8, 8, "+", 10)
    p.lsh(10, 9, -5)
    p.iop(8, 8, "+", 10)
    p.lsh(10, 9, -7)
    p.iop(8, 8, "+", 10)
    p.st(LIMIT, 8)
    tail_limit(p)
    p.place(keep)
    p.ld(8, LIMIT)
    p.e("R8 = PASS R8;")
    p.jump("NE", ok)
    p.iconst(8, LIMIT_DEFAULT)
    p.st(LIMIT, 8)
    p.place(ok)
    p.iconst(8, 0)
    p.st(INS_ACC, 8)                           # 2026-11-10: the inserts' time, this frame's from here


def tail_limit(p) -> None:
    """v0.32: LIMIT = min(0.6 P, max(P - TAIL - P/8, P/4)), P the frame's length (R9 on entry).
    TAIL: the last frame's busy stretch after our entry (idle_load's AFTER moved on: the idle
    task ran since) less our own time then (OURS_END - PREV_MARK), held at its peak and eased
    by 1/4096 a frame; a reading that is not between 0 and 0.7 P is not taken. With no reading
    (the runner, or no idle time at all) TAIL stays 0 and the limit 0.6 P, as before. 2026-11-11: and
    REST_OUT, the stretch from the bus pass's end (INS_BUSEND) to the busy end (under P/4), held the same way.
    Emit only (as the rest of the guard). Clobbers R8, R10-R13."""
    p.comment("v0.32: the stock's tail after our voices, measured, sets the limit")
    no = p.label("tno")
    done = p.label("tdone")
    p.e("R13 = PASS R9;", "P")
    p.ld(8, AFTER)
    p.ld(10, PREV_AFTER)
    p.st(PREV_AFTER, 8)
    p.e("R8 = R8 - R10;", "AFTER's move: the last stretch from our entry")
    p.jump("EQ", no)
    rno = p.label("rno")                       # 2026-11-11: REST_OUT, the stretch after the bus pass
    p.ld(11, PREV_MARK)
    p.e("R11 = R11 + R8;", "the last frame's busy end ..")
    p.ld(12, INS_BUSEND)
    p.e("R11 = R11 - R12;", ".. less the bus pass's end")
    p.jump("LE", rno)
    p.lsh(12, 13, -2)
    p.e("COMP(R11, R12);")
    p.jump("GE", rno)                          # not under P/4: not taken
    p.ld(12, REST_OUT)
    p.iop(11, 11, "MAX", 12)
    p.st(REST_OUT, 11)
    p.place(rno)
    p.ld(10, OURS_END)
    p.ld(11, PREV_MARK)
    p.e("R10 = R10 - R11;", "our own time then")
    p.e("R8 = R8 - R10;", "the stock's tail ..")
    p.ld(10, INS_ACC)
    p.e("R8 = R8 - R10;", ".. less the inserts' (2026-11-10)")
    p.jump("LE", no)
    p.lsh(10, 13, -1)                          # 0.7 P = P/2 + P/8 + P/16 (0.6875)
    p.lsh(11, 13, -3)
    p.iop(10, 10, "+", 11)
    p.lsh(11, 13, -4)
    p.iop(10, 10, "+", 11)
    p.e("COMP(R8, R10);")
    p.jump("GE", no)
    p.ld(10, TAIL)
    p.iop(8, 8, "MAX", 10)
    p.st(TAIL, 8)
    p.place(no)
    p.ld(8, REST_OUT)
    p.lsh(10, 8, -12)
    p.e("R8 = R8 - R10;", "REST_OUT eased as TAIL")
    p.st(REST_OUT, 8)
    p.ld(8, TAIL)
    p.lsh(10, 8, -12)
    p.e("R8 = R8 - R10;", "eased by 1/4096 (about 3 s)")
    p.st(TAIL, 8)
    p.ld(10, MARK)
    p.st(PREV_MARK, 10)
    p.e("R10 = R13 - R8;", "P - TAIL")
    p.lsh(11, 13, -3)
    p.e("R10 = R10 - R11;", "less P/8")
    p.st(INS_DEADLINE, 10)                     # 2026-11-10: the inserts' deadline
    p.lsh(11, 13, -2)
    p.e("COMP(R10, R11);")
    p.jump("GE", done)
    p.e("R10 = PASS R11;", "at least P/4")
    p.place(done)
    keep = p.label("tkeep")
    p.ld(8, LIMIT)
    p.e("COMP(R10, R8);")
    p.jump("GE", keep)
    p.st(LIMIT, 10)
    p.place(keep)


def meter(p, dst: int) -> None:
    """v0.32, the load meter: DST = the DSP's load since the last call, in permille: 1000 -
    1000 x (idle cycles / cycles), idle_load's total against EMUCLK, held to 0..1000; 0 when no
    time passed (the runner's clock does not move) or more than 2^31 cycles (over two
    seconds). Emit only (the runner's model never builds the idle packet). Clobbers R8,
    R10-R13."""
    from .machines import _recip_inline
    if p.run:                                  # the model (dnfw.sampler.live's packets): no clock, 0
        p.iconst(8, 0)
        p.st(dst, 8)
        return
    p.comment("v0.32: the DSP's load since the last idle packet, permille")
    zero = p.label("mzero")
    done = p.label("mdone")
    p.e("R8 = EMUCLK;")
    p.ld(10, METER_NOW)
    p.st(METER_NOW, 8)
    p.e("R8 = R8 - R10;", "cycles since")
    p.jump("LE", zero)
    p.ld(11, IDLE_TOTAL)
    p.ld(10, METER_IDLE)
    p.st(METER_IDLE, 11)
    p.e("R11 = R11 - R10;", "idle cycles since")
    p.iconst(12, 0)
    p.float_(8, 8, 12)
    p.float_(11, 11, 12)
    _recip_inline(p, 10, 8, 13)                # F10 = 1 / cycles (clobbers R12, R13)
    p.fop(11, 11, "*", 10)                     # idle share
    p.fconst(12, 1000.0)
    p.fop(11, 11, "*", 12)
    p.fop(11, 12, "-", 11)                     # 1000 - 1000 x idle share
    p.fconst(12, 0.0)
    p.fop(11, 11, "MAX", 12)
    p.fconst(12, 1000.0)
    p.fop(11, 11, "MIN", 12)
    p.trunc(8, 11)
    p.st(dst, 8)
    p.jump("", done)
    p.place(zero)
    p.iconst(8, 0)
    p.st(dst, 8)
    p.place(done)


def end_mark(p) -> None:
    """v0.32: OURS_END = EMUCLK, as our voices finish (smp.asm's tail). Clobbers R8."""
    p.e("R8 = EMUCLK;", "v0.32: our voices are done")
    p.st(OURS_END, 8)


def perc_limit(p, smp_types, smp_state: int, smp_stride: int, on_word: int, trig_word: int,
               frame_type) -> None:
    """v0.49, once a frame after entry(): RESERVE = the expected cost of every sample voice that
    is sounding (its state's ON word) or triggered this block, each as around() expects it
    (its last cost x 1.5, at least FLOOR), at most 3/4 of LIMIT; LIMIT_PERC = LIMIT - RESERVE.
    PERC's and the Monomachine's voices then give way first, and a sample voice (cheap) is not
    starved by them. A sample slot's new note clears its STRUCK bit. FRAME_TYPE(p, d, k2):
    Rd = slot t's machine type from the frame, Rk2 = 2 t. Clobbers R0-R14, I1, I4."""
    p.comment("v0.49: the sample voices' time held back from PERC's")
    p.ld(3, trig_word)
    p.lsh(3, 3, -16)                           # R3: this block's note triggers, bit t
    p.ld(8, STRUCK)                            # a new note: no strikes
    p.iop(9, 8, "AND", 3)
    p.e("R8 = R8 - R9;")
    if p.run:
        p.setR(8, p.r[8] - p.r[9])
    p.st(STRUCK, 8)
    p.iconst(0, 0)
    p.st(RESERVE, 0)

    def body():
        p.ld(9, RES_I)
        p.iconst(12, 1)
        p.e("R9 = R9 - R12;", "t")
        if p.run:
            p.setR(9, p.r[9] - 1)
        p.iop(10, 9, "+", 9)
        frame_type(p, 2, 10)                   # R2: slot t's machine type
        p.iconst(14, 0)
        for ty in smp_types:
            p.iconst(12, ty)
            p.if_(2, "EQ", 12, lambda: p.iconst(14, 1), kind="i")

        def sample():
            p.ld(9, RES_I)
            p.iconst(12, 1)
            p.e("R9 = R9 - R12;")
            if p.run:
                p.setR(9, p.r[9] - 1)
            p.iconst(10, 1)
            p.e("R10 = LSHIFT R10 BY R9;")
            if p.run:
                p.setR(10, 1 << (p.r[9] & 31))
            p.iop(10, 10, "AND", 3)            # triggered this block
            p.lsh(12, 9, {128: 7}[smp_stride])
            p.iconst(11, smp_state)
            p.iop(12, 11, "+", 12)
            p.seti(4, 12)
            p.ldi(5, on_word, 4, "sounding")
            p.iop(5, 5, "OR", 10)

            def expect():
                p.lsh(12, 9, 2)
                p.iconst(11, COST_SMP)
                p.iop(12, 11, "+", 12)
                p.seti(4, 12)
                p.ldi(13, 0, 4, "its last cost")
                p.lsh(12, 13, -1)
                p.iop(13, 13, "+", 12)         # x 1.5
                p.iconst(12, FLOOR)
                p.iop(13, 13, "MAX", 12)
                p.ld(8, RESERVE)
                p.iop(8, 8, "+", 13)
                p.st(RESERVE, 8)
            p.ifz(5, "NE", expect)
        p.ifz(14, "NE", sample)
    p.loop(RES_I, 16, body)
    p.ld(8, LIMIT)
    p.lsh(9, 8, -1)
    p.lsh(10, 8, -2)
    p.iop(9, 9, "+", 10)                       # 3/4 LIMIT
    p.ld(10, RESERVE)
    p.iop(10, 10, "MIN", 9)
    p.e("R8 = R8 - R10;")
    if p.run:
        p.setR(8, p.r[8] - p.r[10])
    p.st(LIMIT_PERC, 8)


def around(p, t_word: int, cost: int, buffers: int, voice, rests: int | None = None,
           rest_blocks: int = 0, strikes: int | None = None, steal_at: int = 1,
           limit: int = LIMIT, struck: int | None = None, stop=None, keys: int | None = None,
           admit=None, reserve=None) -> None:
    """VOICE() if it fits, else the slot's buffer zeroed and the skip counted. T_WORD:
    the scratch word holding the slot; COST: the slots' cost words; BUFFERS: the track
    buffers' pointers (0x254a60). v0.36: RESTS (the slots' rest counters) given, a voice
    left out (with STRIKES, the slots' strike counters: left out STEAL_AT times in one note) is stolen: its counter set to REST_BLOCKS, so it rests (silent, free) until
    its next note, as a synth steals its oldest voice. Before, it was tried again the next
    block and, with time short, flickered in and out (DDRW's four-note chord: one block
    two voices, the next one). v0.49: LIMIT the limit word (PERC's: LIMIT_PERC); STRUCK and
    STOP (a sample voice): left out a second time in one note (STRUCK's bit t set by the
    first), STOP() ends the voice until its next note, instead of a crunchy flicker. 2026-11-15: RESERVE() adds to R8
    (how far into the frame plus the voice's expected cost) what must still fit after this voice (ANALOG 2's PARA: a
    chord's member keeps its leader's room, dnfw.engines.analog2.para.reserve); it keeps R8 and I5."""
    skip = p.label("gskip")
    done = p.label("gdone")
    p.e("R8 = EMUCLK;")
    p.st(START, 8)
    p.ld(9, MARK0)
    p.e("R8 = R8 - R9;", "how far into the frame")
    p.ld(9, t_word)
    p.lsh(9, 9, 2)
    p.iconst(10, cost)
    p.iop(9, 10, "+", 9)
    p.seti(5, 9)
    p.ldi(9, 0, 5, "this slot's last cost")
    if keys is not None:
        p.ipass(13, 9)                         # (the last cost, for PLAITS' 1.25 below)
    p.lsh(10, 9, -1)
    p.iop(9, 9, "+", 10)                       # x 1.5
    if keys is None:
        p.iconst(10, FLOOR)
        p.iop(9, 9, "MAX", 10)
    else:
        p.comment("b6: a PLAITS slot with a measured cost: at least PLAITS_FLOOR, else FLOOR")
        nob = p.label("gnob")
        flo = p.label("gflo")
        q15 = p.label("gq15")
        _key_and_bound(p, t_word, keys)
        p.comment("2026-11-10 (poly16): a PLAITS slot: 1.25 x its last cost, not 1.5 x (PLAITS_SLACK_SHIFT)")
        p.e("R11 = PASS R11;")
        p.jump("EQ", q15)
        p.lsh(12, 13, -PLAITS_SLACK_SHIFT)
        p.iop(9, 13, "+", 12)
        p.place(q15)
        p.iconst(12, FLOOR)
        p.e("R11 = PASS R11;")
        p.jump("EQ", flo)
        p.comment("2026-11-10 (poly16): a PLAITS slot without a measured cost (a start, FRESH, or never")
        p.comment("rendered): its start bound, not FLOOR (at 60,000 a voice refused in its start never")
        p.comment("got a cost, stayed at FLOOR and was refused until stolen: the runner's poly16)")
        p.e("R12 = PASS R11;")
        p.e("R9 = PASS R9;")
        p.jump("EQ", flo)
        p.iconst(12, PLAITS_FLOOR)
        p.place(flo)
        p.iop(9, 9, "MAX", 12)
        p.comment("2026-11-09: a PLAITS note's first blocks: expected at its fixed bound, not the slot's")
        p.comment("stored cost (a start block's, another note's: stale)")
        p.e("R11 = PASS R11;")
        p.jump("EQ", nob)
        p.iconst(12, 16 * START_BLOCKS)
        p.e("COMP(R10, R12);")
        p.jump("GE", nob)
        p.e("R9 = PASS R11;", "the machine's start bound")
        p.place(nob)
    p.iop(8, 8, "+", 9)
    if reserve is not None:
        reserve()
    ok = p.label("gok") if admit is not None else None
    if admit is not None:                      # 2026-11-12 (dnfw.perc.pairs): a voice rendered ahead is admitted
        admit(ok)
    p.ld(10, limit)
    p.e("COMP(R8, R10);")
    p.jump("GT", skip)
    if admit is not None:
        p.place(ok)
    voice()
    p.e("R8 = EMUCLK;")
    p.ld(9, START)
    p.e("R8 = R8 - R9;", "what the voice cost")
    if admit is not None:                      # 2026-11-12 (dnfw.perc.pairs): a pair's partner render on its own slot
        from . import pairs as PAIRS
        PAIRS.shift(p, t_word)
    steady = p.label("gsteady")
    p.ld(10, FRESH)
    p.e("R10 = PASS R10;")
    p.jump("EQ", steady)
    p.comment("2026-11-09: a start block (FRESH): its cost kept as 0, the flag cleared")
    p.iconst(8, 0)
    p.st(FRESH, 8)
    p.place(steady)
    p.ld(9, t_word)
    p.lsh(9, 9, 2)
    p.iconst(10, cost)
    p.iop(9, 10, "+", 9)
    p.seti(5, 9)
    p.sti(0, 5, 8)
    p.jump("", done)
    p.place(skip)
    p.comment("no time left in this frame: the voice is silent this block (its state kept),")
    p.comment("and its expected cost eased by a quarter, so it is tried again")
    if rests is not None:
        def steal():
            p.ld(9, t_word)
            p.lsh(9, 9, 2)
            p.iconst(10, rests)
            p.iop(9, 10, "+", 9)
            p.seti(4, 9)
            p.iconst(9, rest_blocks)
            p.sti(0, 4, 9)
            count_steal(p)                   # 2026-11-22: the meter's CUT
        if strikes is None:
            p.comment("v0.36: stolen: it rests until its next note")
            steal()
        else:
            p.comment("v0.36: a strike; at STEAL_AT strikes in one note, stolen: it rests until its next note")
            nostrike = p.label("gnostr")
            if keys is not None:
                p.comment("2026-11-09: a PLAITS note's newest block (its trig block): no strike")
                _key_and_bound(p, t_word, keys)
                p.e("R11 = PASS R11;")
                p.jump("EQ", f"{nostrike}x")
                p.iconst(12, 16)
                p.e("COMP(R10, R12);")
                p.jump("LT", nostrike)
                p.place(f"{nostrike}x")
            p.ld(9, t_word)
            p.lsh(9, 9, 2)
            p.iconst(10, strikes)
            p.iop(9, 10, "+", 9)
            p.seti(4, 9)
            p.ldi(9, 0, 4)
            p.iconst(10, 1)
            p.iop(9, 10, "+", 9)
            p.sti(0, 4, 9)
            p.iconst(10, steal_at)
            p.if_(9, "GE", 10, steal, kind="i")
            p.place(nostrike)
        p.ld(9, t_word)                        # I5 again: the slot's cost word
        p.lsh(9, 9, 2)
        p.iconst(10, cost)
        p.iop(9, 10, "+", 9)
        p.seti(5, 9)
    if struck is not None:
        p.comment("v0.49: a sample voice left out a second time in this note stops until its next")
        p.ld(9, t_word)
        p.iconst(10, 1)
        p.e("R10 = LSHIFT R10 BY R9;")
        if p.run:
            p.setR(10, 1 << (p.r[9] & 31))
        p.ld(8, struck)
        p.iop(11, 8, "AND", 10)
        p.ifz(11, "NE", lambda: (stop(), count_steal(p)),   # (2026-11-22: the meter's CUT)
              lambda: (p.iop(8, 8, "OR", 10), p.st(struck, 8)))
        p.ld(9, t_word)                        # I5 again: the slot's cost word
        p.lsh(9, 9, 2)
        p.iconst(10, cost)
        p.iop(9, 10, "+", 9)
        p.seti(5, 9)
    p.ldi(9, 0, 5)                             # I5: the slot's cost word, still
    p.lsh(10, 9, -2)
    p.e("R9 = R9 - R10;")
    p.sti(0, 5, 9)
    p.ld(8, SKIPS)
    p.iconst(9, 1)
    p.iop(8, 8, "+", 9)
    p.st(SKIPS, 8)
    nomask = p.label("gnomask")
    if keys is not None:
        p.comment("b6: the CPU flag only for a new note (its key's age under NEW_NOTE_BLOCKS)")
        _key_and_bound(p, t_word, keys)
        p.iconst(12, 16 * NEW_NOTE_BLOCKS)
        p.e("COMP(R10, R12);")
        p.jump("GE", nomask)
    p.ld(9, t_word)                            # v0.30: and which slot, for the page's CPU flag
    p.iconst(10, 1)
    p.e("R10 = LSHIFT R10 BY R9;")
    if p.run:
        p.setR(10, 1 << (p.r[9] & 31))
    p.ld(8, SKIPMASK)
    p.iop(8, 8, "OR", 10)
    p.st(SKIPMASK, 8)
    p.place(nomask)
    p.ld(9, t_word)
    p.lsh(9, 9, 2)
    p.iconst(10, buffers)
    p.iop(9, 10, "+", 9)
    p.seti(5, 9)
    p.ldi(9, 0, 5)
    # I4, not I5: I5 is the DT2 decimator's, used only pre-modified (its L5 may be a
    # circular length on the unit, which a post-modify would wrap into stock memory)
    p.seti(4, 9, "the slot's buffer")
    p.iconst(8, 0)
    p.loop(COUNT, 8, lambda: [p.stpost(4, 8) for _ in range(4)])
    p.place(done)


# -- 2026-11-10: the inserts (dnfw.inserts): their time apart, and their deadline ---------------------
def ins_start(p, k: int | None = None) -> None:
    """an insert pass begins: INS_T0 = EMUCLK, and INS_DLP = this pass's deadline (cycles after MARK0; 0
    when none is known yet). 2026-11-11 (the unit's telemetry: FDN8/XDLY on the bus passed through for
    thousands of blocks at a 60 % frame, no voice skipped): INS_DEADLINE leaves room for the WHOLE stock
    tail (TAIL), but a pass that starts late in it (the post pass at the sends, the bus pass before the
    output stage) has part of that tail behind it. The stock's time done since our voices and before this
    pass, INS_T0 - OURS_END - INS_ACC (the earlier passes' time out), is added back, held to 0 .. TAIL -
    REST_OUT (what follows the last pass, the output stage, measured: TAIL can read low, as its readings
    over 0.7 P are not taken). Emit only. Clobbers R8, R9."""
    if p.run:
        return
    z = p.label("isz")
    p.e("R8 = EMUCLK;", "the inserts' time: this pass from here")
    p.st(INS_T0, 8)
    p.ld(9, OURS_END)
    p.e("R8 = R8 - R9;", "since our voices ..")
    p.ld(9, INS_ACC)
    p.e("R8 = R8 - R9;", ".. the stock's time done before this pass")
    p.ld(9, REST_OUT)
    p.e("R8 = R8 + R9;")
    p.ld(9, TAIL)
    p.iop(8, 8, "MIN", 9)
    p.ld(9, REST_OUT)
    p.e("R8 = R8 - R9;", "held to TAIL - REST_OUT: the output stage is always to come")
    p.iconst(9, 0)
    p.iop(8, 8, "MAX", 9)
    p.ld(9, INS_DEADLINE)
    p.e("R9 = PASS R9;")
    p.jump("EQ", z)
    p.e("R9 = R9 + R8;", "no longer to come")
    p.place(z)
    p.st(INS_DLP, 9)
    if k is not None:
        assert 0 <= k < INS_ROOM_PASSES
        nz = p.label("irz")
        p.e("R9 = PASS R9;")
        p.jump("EQ", nz)
        p.e("R8 = EMUCLK;")
        p.e("R8 = R9 - R8;", "the room before this pass's deadline ..")
        p.ld(9, MARK0)
        p.e("R8 = R8 + R9;", ".. from here, in the frame")
        p.ld(9, INS_ROOM + 4 * k)
        p.iop(8, 8, "MIN", 9)
        p.st(INS_ROOM + 4 * k, 8)
        p.place(nz)


def ins_end(p, last: bool = False) -> None:
    """an insert pass ends: INS_ACC += EMUCLK - INS_T0; LAST (the bus pass): INS_BUSEND = EMUCLK too (2026-11-11,
    REST_OUT). 2026-11-12: K given (the pass, INS_ROOM's index), INS_ROOM[K] = min(itself, INS_DLP - (EMUCLK - MARK0))
    when a deadline is known. Emit only. Clobbers R8, R9."""
    if p.run:
        return
    p.e("R8 = EMUCLK;")
    if last:
        p.st(INS_BUSEND, 8)
    p.ld(9, INS_T0)
    p.e("R8 = R8 - R9;", "this pass's time")
    p.ld(9, INS_ACC)
    p.e("R8 = R8 + R9;")
    p.st(INS_ACC, 8)


def ins_gate(p, cost_at: int, aux_at: int, status_at: int, run, grace: bool = False, typ_at: int | None = None) -> None:
    """2026-11-12 (main: the unit's skips toggled inserts wet / dry every block, a click each): RUN() for an insert
    instance by its bound (the word at COST_AT) against the pass's deadline, as ins_admit, but an instance once
    refused stays out until it has fitted INS_HOLD blocks in a row. Its out count is word 2 of its aux words (the
    address at AUX_AT). STATUS_AT gets 0 ran, 1 ran again after being out, 2 left out (just refused), 3 left out
    (still); 2 and 3 count in INS_SKIPS. The model reads INS_TESTCLK for EMUCLK (0 deadline: every block fits, as
    the runner). GRACE (the bus pass, opt-host's ins_fade): a refusal still within P/16 past the deadline is 4, RUN
    once more (the caller fades it out over that block), counted as left out. TYP_AT (opt-host's INS_TSKIP, 2026-11-12):
    the word holding the type; a block just refused counts under it, a held-out one under 14, a faded one under 15.
    Clobbers R0-R3, R8-R10, R12, I4 before RUN."""
    p.iconst(9, 1)                               # fits
    p.ld(10, INS_DLP)

    def check():
        if p.run:
            p.ld(8, INS_TESTCLK)
        else:
            p.e("R8 = EMUCLK;")
        p.ld(9, MARK0)
        p.iop(8, 8, "-", 9)
        p.ld(9, cost_at)
        p.iop(8, 8, "+", 9)
        p.iconst(9, 1)
        p.if_(8, "GT", 10, lambda: p.iconst(9, 0), kind="i")
    p.ifz(10, "NE", check)
    p.ld(2, aux_at)
    p.seti(4, 2)
    p.ldi(3, 2, 4)                               # the out count

    def fits():
        def back():
            p.iconst(12, 1)
            p.iop(3, 3, "-", 12)
            p.sti(2, 4, 3)
            p.iconst(0, 3)
            p.ifz(3, "EQ", lambda: p.iconst(0, 1))
        p.iconst(0, 0)
        p.ifz(3, "NE", back)

    def refused():
        def just():
            p.iconst(0, 2)
            if grace:                            # R8: when it would end, R10 the deadline
                p.ld(1, PERIOD)
                p.lsh(1, 1, -4)
                p.iop(1, 10, "+", 1)
                p.if_(8, "LE", 1, lambda: p.iconst(0, 4), kind="i")
        p.iconst(0, 3)
        p.ifz(3, "EQ", just)
        p.iconst(3, INS_HOLD)
        p.sti(2, 4, 3)
    p.ifz(9, "NE", fits, refused)
    p.st(status_at, 0)
    p.iconst(1, 2)

    def out():
        p.ld(8, INS_SKIPS)
        p.iconst(9, 1)
        p.iop(8, 8, "+", 9)
        p.st(INS_SKIPS, 8)
        if typ_at is not None and not p.run:
            p.iconst(1, INS_TSKIP_WORDS - 2)     # 14: held out
            p.iconst(2, 2)
            p.if_(0, "EQ", 2, lambda: p.ld(1, typ_at), kind="i")
            p.iconst(2, 4)
            p.if_(0, "EQ", 2, lambda: p.iconst(1, INS_TSKIP_WORDS - 1), kind="i")   # 15: faded
            count_skip_r(p, 1)
    p.if_(0, "GE", 1, out, kind="i")
    p.ld(0, status_at)                           # RUN once in the code: 0, 1, and (GRACE) 4
    if grace:
        p.iconst(1, 4)
        p.if_(0, "EQ", 1, lambda: p.iconst(0, 0), kind="i")
    p.iconst(1, 2)
    p.if_(0, "LT", 1, run, kind="i")


# 2026-11-12 (round 13, main: which insert is refused): the blocks left out per insert type, 16 words in L1 (the memory
# arbiter's allotment, F2's tail after opt-mnm's table; zeros at power-on, dnfw.waverider.dsp's span): words 0..13 the
# types (dnfw.inserts.design), 14 and 15 kept for the inserts' own gate (opt-inserts: held out, faded). Cumulative; the
# idle packet's units 42..57 carry their low 16 bits to the ColdFire (link.c smp_ins_tskip, DIAG)
INS_TSKIP = 0x2E1700
INS_TSKIP_WORDS = 16
# .. then each insert pass's least room before its deadline since the ColdFire last heard (INS_DLP - (EMUCLK - MARK0)
# as the pass starts, signed cycles; ins_start(p, k)): k 0 the A2 filters, 1 the pre pass, 2 the post pass, 3 the bus
# pass. 0x7FFFFFFF: none seen (power-on, and after each idle packet). Read with TAIL by the idle packet (units 58..62):
# the unit's own measure of how close the deadline is, for the guard's margin (main's (a))
INS_ROOM = INS_TSKIP + 4 * INS_TSKIP_WORDS
INS_ROOM_PASSES = 4
INS_ROOM_NONE = 0x7FFFFFFF
INS_TEL_END = INS_ROOM + 4 * INS_ROOM_PASSES


def count_skip(p, typ: int | None = None, typ_at: int | None = None) -> None:
    """INS_TSKIP[type] + 1: TYP the type, or TYP_AT the address of the word holding it (its low 4 bits). Emit only.
    Clobbers R8, R9, R12 (and I4 by TYP_AT)"""
    if p.run:
        return
    if typ is not None:
        assert 0 <= typ < INS_TSKIP_WORDS
        at = INS_TSKIP + 4 * typ
        p.ld(8, at)
        p.iconst(9, 1)
        p.e("R8 = R8 + R9;")
        p.st(at, 8)
        return
    p.ld(9, typ_at)
    p.iconst(12, INS_TSKIP_WORDS - 1)
    p.iop(9, 9, "AND", 12)
    p.lsh(9, 9, 2)
    p.iconst(12, INS_TSKIP)
    p.iop(9, 12, "+", 9)
    p.seti(4, 9)
    p.ldi(8, 0, 4)
    p.iconst(12, 1)
    p.e("R8 = R8 + R12;")
    p.sti(0, 4, 8)


def count_skip_r(p, r: int) -> None:
    """INS_TSKIP[R{r} & 15] + 1 (the inserts' own gate, opt-inserts: the type in a register). Emit only. Clobbers R8,
    R9, R12, I4 (so R must not be one of R8, R9, R12)"""
    assert r not in (8, 9, 12)
    if p.run:
        return
    p.iconst(12, INS_TSKIP_WORDS - 1)
    p.iop(9, r, "AND", 12)
    p.lsh(9, 9, 2)
    p.iconst(12, INS_TSKIP)
    p.iop(9, 12, "+", 9)
    p.seti(4, 9)
    p.ldi(8, 0, 4)
    p.iconst(12, 1)
    p.e("R8 = R8 + R12;")
    p.sti(0, 4, 8)


def ins_admit(p, cost: int, run, typ: int | None = None, typ_at: int | None = None) -> None:
    """RUN() if the insert is expected to end before its pass's deadline (INS_DLP: EMUCLK - MARK0
    + COST), or no deadline is known yet (0: the runner, a frame not measured); else INS_SKIPS + 1 and the
    insert left out of this block (the sound passes as it is), and (2026-11-12) its type's count (count_skip) when TYP
    or TYP_AT is given. The model always runs it (the runner's clock does not move either). Clobbers R8-R10 before RUN (and R12,
    I4 when left out)."""
    if p.run:
        run()
        return
    go = p.label("iago")
    done = p.label("iadone")
    p.ld(10, INS_DLP)
    p.e("R10 = PASS R10;")
    p.jump("EQ", go)
    p.e("R8 = EMUCLK;")
    p.ld(9, MARK0)
    p.e("R8 = R8 - R9;", "into the frame")
    p.iconst(9, cost)
    p.e("R8 = R8 + R9;", "and this insert's bound")
    p.e("COMP(R8, R10);")
    p.jump("LE", go)
    p.ld(8, INS_SKIPS)
    p.iconst(9, 1)
    p.e("R8 = R8 + R9;")
    p.st(INS_SKIPS, 8)
    if typ is not None or typ_at is not None:
        count_skip(p, typ, typ_at)
    p.jump("", done)
    p.place(go)
    run()
    p.place(done)
