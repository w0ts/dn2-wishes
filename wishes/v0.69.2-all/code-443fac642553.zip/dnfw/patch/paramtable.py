"""Move the instrument's parameter table somewhere it can grow, and grow it.

The Digitone II describes every knob it has in one table of 320 records, 60
bytes each, at `0x401f83d8` **inside the firmware image**. A fourth LFO needs
ten more records, and the table cannot grow in place: the next byte after it
already belongs to another array (`0x401fced8`).

So the table is copied into the appended area with ten records after it, and
every instruction that reaches the old one is repointed. That is possible only
because of how the accessors are written, which is worth stating once:

    cmpil #321,%d0                 ; the entry space, entry = index + 1
    scs %d1 ; mvsb %d1,%d1 ; andl %d1,%d0
    lea 0x401f83a4,%a0             ; table - 60 + 8: the base, PRE-BIASED
    movel %d0,%d1 ; lsll #2,%d1 ; lsll #6,%d0 ; subl %d1,%d0
    movel %a0@(0,%d0:l),%d0

**Every accessor carries its own biased base and recomputes the address**;
none caches a pointer and no record boundary appears as a literal anywhere. So
rewriting the bases redirects every lookup there is. Three biases are in use --
`- 60 + 8`, `- 60 + 16`, `- 60 + 40`, one per field an accessor wants -- and
this module finds their sites by searching for the literal rather than holding
an address list, then asserts the count it expects to find.

A second table shadows the first at run time: **321 entries of 68 bytes** at
`0x4243425c`, indexed by the same entry number, which is why it shares the
`321`. It **does not move**, and `runtime_literals` is why: its initialiser is
**unrolled**, and writes every entry's field addresses as absolute literals --
902 of them, covering entries 0 to 320 with no gaps. There is no base to
repoint. Its bound stays where it is too, so an entry past 320 clamps to entry
0 there exactly as it always did.

**What a missed site does, because that decides how much this may be trusted.**
A missed *base* keeps reading the old table, which is still there and still
correct for entries 1..320; it reads garbage only for the ten new ones. A
missed *bound* clamps a new entry to the fallback record. Both are visibly
wrong on the new page and harmless everywhere else -- this patch cannot turn a
stock parameter into a wrong one, because the copy is byte-identical for every
record that already existed.

**A bound raised where it should not be is the dangerous direction**, and it is
not symmetric with the above: `NOT_THIS_TIME` holds the two that must stay, and
one of them writes past the end of somebody else's table if it moves. Read
those entries before adding to the list or removing from it.
"""

from __future__ import annotations

import struct
from dataclasses import dataclass

# Stock 1.11's last byte. Every site this module rewrites is in the firmware's
# own code, and a build's `content` is longer than that: the appended area,
# with this project's compiled C in it, follows. Scanning past this point finds
# **our own** constants -- `lfo4_comp_stub` compares against `LFO4_ENTRY0`,
# which is 321, and assembles to the very `cmpil #321` this module hunts for.
# Two of those turned a 53-site list into a 55-site one, and without the count
# assertion the build would have "raised the bound" inside its own stub.
STOCK_END = 0x4030C980

TABLE, RECORD, COUNT = 0x401F83D8, 60, 320
# OS 1.11's, for the 1.11 mods that only check the table is where stock keeps it (fxmod: base_sites): 2026-11-17,
# the 1.12 port left base_sites refusing every 1.11 image, so fxmod applied to neither OS
STOCK_END_111, TABLE_111 = 0x4030B980, 0x401F7FC8
BIASES = (8, 16, 40)                       # the field each accessor wants
EXPECTED_BASES = {8: 53, 16: 1, 40: 2}     # measured on stock 1.11, 56 in all (the same on 1.12: gen_lfo4_code)

RUNTIME, RUNTIME_STRIDE, RUNTIME_ENTRIES = 0x4243425C, 68, 321
EXPECTED_RUNTIME = 902                     # the unrolled initialiser's literals

# `cmpil #320` and `cmpil #321` both spell the same bound -- `bhi` against 320
# rejects, `scs` against 321 keeps -- so both forms are rewritten. Three sites
# hold a 320 that is **not** this bound: loops that step `d2` by 20 up to 320,
# sixteen iterations of something else entirely (0x40031fd8 and its two twins).
# They are named here so that the count still checks.
NOT_THE_BOUND = (0x40031FEE, 0x40032422, 0x400325E2)

# And one site that **is** this bound and must be left alone anyway.
#
# `param_set_tables_build` (0x400dc634) walks every record and files its entry
# number into tables indexed by the record's **value slot**, one of them per
# parameter group: `0x42c65b3c`, `0x42c657ac` and `0x42c659a8`, each of which
# the same routine zeroes with `pea 0x194` -- 404 bytes, **101 longwords**, one
# per slot 0..100. LFO4's records carry slots 101-108, which is 32 bytes past
# the end of each, and the byte after `0x42c65b3c`'s 404th is `0x42c65cd0`, the
# filter table this routine zeroes two calls earlier.
#
# So raising this one bound registers ten records into three tables that have
# no room for them and silently overwrites the table next door. It boots, it
# draws, and it would have gone to the instrument: the class of fault a gate
# watching for crashes cannot see.
#
# Left at 321, the loop walks the relocated table's first 320 records and does
# exactly what stock does. LFO4's slots stay unregistered, which is the read
# side -- `0x400dc18e` bounds slots at 100 in its own right, so it answers 0 for
# 101 either way. Growing those three tables to 109 entries is five literals
# each plus a size immediate, and it belongs with the rest of the read side.
#
# And `0x400c2580` guards the 68-byte companion table, which `runtime_literals`
# shows cannot move: entry 321 there would be 68 bytes past a table that ends
# where the RTOS's task blocks begin. Left at 321 it clamps to entry 0, the
# fallback, exactly as an out-of-range entry always did.
NOT_THIS_TIME = {0x400DC954: "param_set_tables_build files by value slot into "
                             "101-entry tables; see docs/lfo4-build-plan.md",
                 0x400C2580: "the 68-byte companion table has no base to move; "
                             "past its end are the RTOS task blocks"}
EXPECTED_BOUNDS = 53


class TableError(ValueError):
    """The image does not hold what this module was measured against."""


@dataclass(frozen=True)
class Site:
    """One literal to rewrite: where it is, what it holds, what it means."""

    va: int
    was: int
    now: int
    what: str

    @property
    def width(self) -> int:
        return 4


def _os(content: bytes, base: int) -> tuple[int, int]:
    """-> (the image's end, the table's address) for the OS this MAIN OS is: 1.12's, or 1.11's when it is exactly
    1.11's length (with or without an appended area it is at least that long)"""
    if len(content) >= STOCK_END - base:
        return STOCK_END, TABLE
    if len(content) >= STOCK_END_111 - base:
        return STOCK_END_111, TABLE_111
    raise ValueError(f"MAIN OS is {len(content):,} B, shorter than OS 1.11's {STOCK_END_111 - base:,}")


def _stock(content: bytes, base: int) -> bytes:
    """`content` cut to the firmware's own image, without the appended area.

    2026-11-14: this module's addresses are OS 1.12's (scripts/port_os112.py, docs/lfo-112-port.md); base_sites
    alone also reads a 1.11 image, at 1.11's table (_os)."""
    end, _ = _os(content, base)
    return content[:end - base]


def _even_occurrences(content: bytes, base: int, value: int) -> list[int]:
    """Every instruction-aligned place the four bytes of `value` appear."""
    want, out, i = struct.pack(">I", value), [], 0
    while True:
        i = content.find(want, i)
        if i < 0:
            return out
        if i % 2 == 0:
            out.append(base + i)
        i += 1


def base_sites(content: bytes, base: int) -> list[Site]:
    """The 56 pre-biased bases of the 60-byte table."""
    _, table = _os(content, base)
    content = _stock(content, base)
    out = []
    for bias in BIASES:
        literal = table - RECORD + bias
        found = _even_occurrences(content, base, literal)
        if len(found) != EXPECTED_BASES[bias]:
            raise TableError(f"expected {EXPECTED_BASES[bias]} site(s) holding "
                             f"0x{literal:08x} (table - {RECORD} + {bias}), found {len(found)}")
        out += [Site(va, literal, 0, f"base, field +{bias}") for va in found]
    return out


def runtime_literals(content: bytes, base: int) -> list[int]:
    """Every absolute address of a 68-byte entry's field, in the image.

    **This is the evidence that the companion table cannot be relocated.** It
    looked like six sites at five field offsets -- which is what a search for
    *entry 0's* fields finds, and what an earlier reading of this recorded. It
    is not: the table's initialiser is **unrolled**, one block per entry, and
    each block writes its own entry's addresses outright:

        pea   <entry + 4>
        pea   <entry + 20>
        clr.l <entry + 0>
        clr.l <entry + 44>
        clr.l <entry + 60>

    902 such literals, covering entries 0 to 320 with **no gaps**. There is no
    base to repoint, so patching the six that mention entry 0 moves the
    *accessor* and leaves the *initialiser* writing where the table used to be:
    the build then reads an empty table forever. Measured, after a build that
    did exactly that put 10,591 writes into the old address range and zero
    reads (`scripts/emu_table_watch.py`, 2026-09-21).
    """
    content = _stock(content, base)
    out = []
    for i in range(0, len(content) - 4, 2):
        value = struct.unpack_from(">I", content, i)[0]
        if not RUNTIME <= value < RUNTIME + RUNTIME_STRIDE * RUNTIME_ENTRIES:
            continue
        if (value - RUNTIME) % RUNTIME_STRIDE not in (0, 4, 20, 44, 60):
            continue
        if struct.unpack_from(">H", content, i - 2)[0] in (0x4879, 0x42B9):   # pea, clr.l
            out.append(base + i)
    return out


def bound_sites(content: bytes, base: int) -> list[Site]:
    """Every `cmpil #320` / `#321` that bounds the entry space.

    A bound belongs to the table when the same function multiplies by 60 --
    `lsl.l #6` and `lsl.l #2` with a subtraction between them -- or walks it
    with `lea 60(aN),aN`. The six that do neither were each disassembled and
    named in `docs/lfo4-build-plan.md`; three are this bound reached through a
    call, three are loops over the table with the stride in an address
    register, and the three in `NOT_THE_BOUND` are not this bound at all.

    `NOT_THIS_TIME` is the other kind of exclusion: a site that is this bound
    and must still be left where it is. Read its entry before changing it.
    """
    content = _stock(content, base)
    out = []
    for value in (320, 321):
        for reg in range(8):
            opcode = bytes([0x0C, 0x80 | reg]) + struct.pack(">I", value)
            i = 0
            while True:
                i = content.find(opcode, i)
                if i < 0:
                    break
                va = base + i
                if i % 2 == 0 and va not in NOT_THE_BOUND and va not in NOT_THIS_TIME:
                    out.append(Site(va + 2, value, 0, f"bound, cmpil #{value},%d{reg}"))
                i += 1
    if len(out) != EXPECTED_BOUNDS:
        raise TableError(f"expected {EXPECTED_BOUNDS} bound sites, found {len(out)}")
    return out


def live_base(stock: bytes, build: bytes, base: int) -> int:
    """The 60-byte table's pre-biased base (`table - 60 + 8`: record ID's bytes start at it + 60 * ID) that
    BUILD's own accessors use: stock's `0x401f83a4`, or where a relocation (lfo4) moved it. For a harness that
    reads records out of RAM: after a move the stock copy stays in the image and no accessor reads it.

    Read from BUILD's code at STOCK's 56 base sites; every one must hold its stock literal plus one and the same
    delta, or the build reads two tables and this raises."""
    if len(stock) < STOCK_END - base:          # an older OS (1.11): this module's sites are 1.12's, and nothing
        literal = TABLE - RECORD + 8            # moves its table; the build must hold stock's base as often as stock
        n_stock = len(_even_occurrences(stock, base, literal))
        n_build = len(_even_occurrences(build[:len(stock)], base, literal))
        if n_stock == 0 or n_build != n_stock:
            raise TableError(f"older MAIN OS: stock holds 0x{literal:08x} {n_stock} time(s), the build {n_build}")
        return literal
    deltas = {struct.unpack_from(">I", build, s.va - base)[0] - s.was for s in base_sites(stock, base)}
    if len(deltas) != 1:
        raise TableError("the build's table accessors disagree on where the table is: deltas "
                         + ", ".join(hex(d) for d in sorted(deltas)))
    return TABLE - RECORD + 8 + deltas.pop()


def records(content: bytes, base: int) -> bytes:
    """The 320 stock records, byte for byte."""
    at = TABLE - base
    return bytes(content[at:at + RECORD * COUNT])


def poke(content: bytearray, base: int, site: Site) -> None:
    at = site.va - base
    here = struct.unpack_from(">I", content, at)[0]
    if here != site.was:
        raise TableError(f"0x{site.va:08x} holds 0x{here:08x}, not the stock "
                         f"0x{site.was:08x} ({site.what})")
    struct.pack_into(">I", content, at, site.now)


def relocate(content: bytearray, base: int, *, table_va: int, added: int) -> list[Site]:
    """Repoint the 60-byte table and widen the entry space by `added` records.

    The 68-byte companion stays where it is; `runtime_literals` is why.

    -> every site it wrote, so the build can print and the caller can count.
    """
    delta = table_va - TABLE
    sites = [Site(s.va, s.was, s.was + delta, s.what) for s in base_sites(content, base)]
    sites += [Site(s.va, s.was, s.was + added, s.what) for s in bound_sites(content, base)]
    for site in sites:
        poke(content, base, site)
    return sites
