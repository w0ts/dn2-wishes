"""A PERC voice playing a Machinedrum machine (docs/md.md): the machine at 44.1 kHz, block
by block, and the DN2's 48 kHz block read from that stream.

`block(p, L, knobs, note, want)` is one DN2 block for the slot whose words I3 points at
(and C['mdb'] holds), writing 32 samples at I4:
  1. the eight knobs (floats 0..1 in the scratch words KNOBS) become the Machinedrum's
     eight 14-bit inputs (the nearest of its 128 knob positions, << 7); a change marks
     the words dirty;
  2. a note (Rnote != 0) asks for machine WANT (the TYPE now) and marks a trig waiting;
  3. if the read position has passed the stream's first block, the stream moves on a
     block and the machine renders the next (`advance`): a waiting note runs init (if the
     machine changes), the host's scale function (as a note) and trig; dirty words run
     the scale function alone (as a parameter change, which some machines answer with
     fewer words, or none, as the Machinedrum does);
  4. 32 samples are read at 0.91875 stream samples a sample with 4-point Catmull-Rom
     interpolation into the DN2's buffer.

Until its first note a slot plays nothing (VW['mach'] is -1).
"""

from __future__ import annotations

from . import core as K
from . import machines as MM
from ..perc.dsl import Prog

N = len(MM.MACHINES)                          # PERC's TYPE spans these
try:                                          # v0.26: the Monomachine's synth machines, chosen by
    from ..mnm import machines as _MNM        # their machine type, after the Machinedrum's
    ALL = MM.MACHINES + _MNM.MACHINES
except ImportError:                           # pragma: no cover
    ALL = MM.MACHINES
N_ALL = len(ALL)
INIT_FIRST = [k for k, M in enumerate(MM.MACHINES) if getattr(M, "INIT_FIRST", False)]
# v0.42: the machines whose voices use the slot's delay area (core.delay_base): P-I, VO-6
_DLY = [k for k, M in enumerate(ALL) if M.NAME.startswith("PI-") or M.NAME == "VO-6"]
DELAY_LO, DELAY_HI = min(k for k in _DLY if ALL[k].NAME.startswith("PI-")), max(k for k in _DLY if ALL[k].NAME.startswith("PI-"))
assert [k for k in _DLY if ALL[k].NAME.startswith("PI-")] == list(range(DELAY_LO, DELAY_HI + 1))
DELAY_ALSO = [k for k in _DLY if not ALL[k].NAME.startswith("PI-")]
KNOB_SCALE = 16256.0                          # knob 0..1 -> 0..127 << 7
START = 35.0                                  # the read position that asks for a new block
QUIET_LEVEL = 2.0 ** -21                      # a block whose peak is under this is silence
QUIET_BLOCKS = 32                             # this many in a row (23 ms) and the machine rests


def _same_code(step: str) -> dict[int, int]:
    """machine index -> the index of the first machine whose STEP is the same code (a
    machine that is another's DSP code with its own scale function, TRX-OH on TRX-CH's,
    shares that machine's render, init and trig): the same function, emitting the same text."""
    def text(M):
        q = Prog("emit", prefix="md_probe")
        q.spill = _PROBE_L.C["ash"]
        getattr(M, step)(q, _PROBE_L)
        return q.text()
    out, seen, by_text = {}, {}, {}
    for k, M in enumerate(ALL):
        if hasattr(M, "MNM"):                 # their own code each, but one host per host function
            # (v0.56: DPRO-DDRW has its own, machines._host_ddrw; the others share machines._host)
            h = getattr(M.host, "__func__", M.host)
            out[k] = seen.setdefault(("mnm_host", h), k) if step == "host" else k
            continue
        f = getattr(M, step)
        key = getattr(f, "__func__", f)
        if key in seen and text(ALL[seen[key]]) == text(M):
            out[k] = seen[key]
            continue
        # 2026-11-21 (DSP room): two functions that emit the same text are the same code too (PI-HH's init is
        # PI-CC's, 110 instructions): the table's JUMP goes to the first copy, as for one function
        t = text(M)
        if t in by_text:
            out[k] = by_text[t]
            continue
        seen.setdefault(key, k)
        by_text[t] = k
        out[k] = k
    return out


_PROBE_L = K.Layout(0x100000, 0x80000, 0x200000)


# 2026-11-12 (perc-layout, scratch/perc-layout/README.md): the steps that run only on events (a knob change, a
# note; measured on the SHARC runner: not one of their instructions in a steady block, 88 cases) are emitted into
# PERC's other L2 spans (dnfw.waverider.dsp PERC2A / PERC2B), leaving PERC's own span to the code every block runs.
# Their dispatch reaches them by the table's 48-bit JUMPs and they leave by one: no instruction changes.
STEP_SPAN = {"host": "perc2a", "init": "perc2b"}


def _each(p: Prog, L: K.Layout, step: str) -> None:
    """STEP of the machine whose index is in VW['mach'] (>= 0; an index past the last, or below 0,
    the last machine's, as the compare chain this replaces gave it): emit mode jumps through a
    table of 48-bit JUMPs, one a machine (2026-11-10, shrink: the chain was 12..18 bytes and up
    to N_ALL compares a machine, the table 6 bytes and one indexed jump), each distinct code
    once; run mode calls the one machine. Clobbers R0, R12, I12 before STEP's code."""
    if p.run:
        K.vw(p, 0, "mach")
        k = p.r[0] if 0 <= p.r[0] < N_ALL else N_ALL - 1
        getattr(ALL[k], step)(p, L)
        return
    same = _same_code(step)
    end = p.label(f"md_{step}_end")
    table = p.label(f"md_{step}_table")
    body = {k: p.label(f"md_{step}_{k}") for k in set(same.values())}
    K.vw(p, 0, "mach")
    p.iconst(12, N_ALL - 1)
    p.iop(0, 0, "MIN", 12)
    p.ifz(0, "LT", lambda: p.iconst(0, N_ALL - 1))
    p.lsh(12, 0, 1)
    p.iop(0, 12, "+", 0)                       # 3 x the index: a JUMP is 3 short words
    p.ret_addr(12, table)                      # the table's address - 1 (JUMP (M14, I12) adds 1)
    p.iop(0, 12, "+", 0)
    p.seti(12, 0)
    p.e("JUMP (M14, I12);")
    p.e("NOP;")                                # never runs: keeps the table's first JUMP out of this
    p.place(table)                             # JUMP's 48-bit window (hwrules BRANCH-WIN)
    for k, M in enumerate(ALL):
        p.jump("", body[same[k]])
    bias3 = p.ibias.get(3)
    for k, M in enumerate(ALL):
        if same[k] == k:
            with p.span(STEP_SPAN.get(step)):
                p.comment(f"---- {M.NAME} {step} ----")
                p.place(body[k])
                getattr(M, step)(p, L)
                # 2026-11-11: each machine's code, emitted one after another, must end with I3 as it
                # found it (the voice's biased slot: shrink's I3_BIAS), or the next one's offsets and
                # the code after the dispatch are off by the bias
                assert p.ibias.get(3) == bias3, f"{M.NAME} {step} leaves I3's bias {p.ibias.get(3)}, not {bias3}"
                p.jump("", end)
    p.place(end)


def _zeros(p: Prog, n: int, i: int = 5, z: int = 6, counter: int = 7) -> None:
    """2026-11-10 (poly16): N zeros from Ii on (Rz already 0), eight stores a pass of a register loop
    (until then a memory-counter loop of one store: about 6 instructions a word, 1.4 now). The same
    words written. Clobbers Rcounter, R12."""
    if n >= 8:
        p.loop_r(counter, n // 8, lambda: [p.stpost(i, z) for _ in range(8)])
    for _ in range(n % 8):
        p.stpost(i, z)


def peak32(p: Prog, i: int, counter: int = 2) -> None:
    """F7 = MAX(F7, |x|) over the 32 words from Ii on, as MAX(F7, x) then MAX(F7, 0 - x) a word
    (2026-11-10, poly16: four words a pass of a register loop, 0.0 held in F13; it was a
    memory-counter loop reloading the 0 every word: 10 instructions a word, ~4.75 now; the same
    operations). 2026-11-12 (opt-host): the words in turn in F6 and F8, each pass's second to fourth
    loaded beside the MAX before it when Ii is one of I0..I3 (dsl.PAR_I): ~3.75 a word. Clobbers F6, F8,
    F13, Rcounter, R12."""
    p.fconst(13, 0.0)

    def four():
        p.ldpost(6, i)
        for k in range(4):
            x, y = (6, 8) if k % 2 == 0 else (8, 6)
            p.fop(7, 7, "MAX", x)
            if k < 3:
                p.ldpost(y, i)                 # the next word (beside the MAX: it reads x, not y)
            p.fop(x, 13, "-", x)
            p.fop(7, 7, "MAX", x)
    p.loop_r(counter, 8, four)


def reset(p: Prog, L: K.Layout) -> None:
    """The slot's words cleared, no machine, the stream asking for a block. Clobbers R0, R6, R7 (2026-11-10),
    R12, I5."""
    p.ld(0, L.C["mdb"])
    p.seti(5, 0)
    p.iconst(6, 0)
    _zeros(p, K.MD_WORDS)
    # v0.24: and its P-I delay lines (the Machinedrum's start as its emulator's: zeros)
    K.delay_base(p, L, 0)
    p.seti(5, 0)
    p.iconst(6, 0)
    _zeros(p, L.delay_words)
    p.iconst(0, -1)
    K.vws(p, "mach", 0)
    p.fconst(0, START)
    K.vws(p, "pos", 0)


ROUTE = 0x257898                         # 16 x s16: the track each voice slot plays (dnfw.inserts.design.ROUTE)


def uses_lines(p: Prog, m: int, d: int) -> None:
    """Rd = 1 when machine Rm uses the P-I delay lines (the P-I machines, VO-6), else 0. Clobbers R12"""
    p.iconst(12, DELAY_LO)
    p.iconst(d, 0)
    p.if_(m, "GE", 12, lambda: (p.iconst(12, DELAY_HI),
                                p.if_(m, "LE", 12, lambda: p.iconst(d, 1), kind="i")), kind="i")
    for k in DELAY_ALSO:
        p.iconst(12, k)
        p.if_(m, "EQ", 12, lambda: p.iconst(d, 1), kind="i")


def new_track(p: Prog, L: K.Layout) -> None:
    """2026-11-14 (delay leaks; the User: "Fix all, start fresh"): a note on a track other than the voice's last
    note's (design ROUTE: the voices go round the tracks) starts its P-I delay lines from silence, when its machine
    uses them: until now a voice handed from one track's PI-BD to another's (the same machine, so no change) kept
    the first track's ringing lines under the second's note. The voice's last track in its word trk. Clobbers R0-R4,
    R6, R7, R12, I5"""
    p.ld(0, L.C["mdb"])
    p.iconst(12, -L.state)
    p.iop(0, 12, "+", 0)
    p.lsh(0, 0, -10)                           # the voice slot (1 KB of words a slot)
    p.lsh(1, 0, -1)
    p.lsh(1, 1, 2)
    p.iconst(12, ROUTE)
    p.iop(2, 12, "+", 1)
    p.seti(5, 2)
    p.ldi(3, 0, 5)                             # the slot pair's word: even slot low half, odd high
    p.iconst(12, 1)
    p.iop(1, 0, "AND", 12)
    p.ifz(1, "NE", lambda: p.lsh(3, 3, -16))
    p.iconst(12, 0xFFFF)
    p.iop(3, 3, "AND", 12)
    K.vw(p, 4, "trk")

    def moved():
        K.vws(p, "trk", 3)
        K.vw(p, 1, "want")
        uses_lines(p, 1, 2)

        def lines():
            K.delay_base(p, L, 0)
            p.seti(5, 0)
            p.iconst(6, 0)
            _zeros(p, L.delay_words)
        p.ifz(2, "NE", lines)
    p.if_(3, "NE", 4, moved, kind="i")


def _move(p: Prog, L: K.Layout) -> None:
    """The stream moves on a block (B[32..66] -> B[0..34]). Clobbers R1, R6, R7, R12, I1, I5."""
    p.ld(1, L.C["mdb"])
    p.iconst(12, 4 * K.B0)
    p.iop(1, 12, "+", 1)
    p.seti(5, 1)                               # I5: B[0]
    p.iconst(12, 4 * 32)
    p.iop(1, 12, "+", 1)
    p.seti(1, 1)                               # I1: B[32]

    def move8():                               # 2026-11-10 (poly16): 8 words a pass of a register loop
        for _ in range(8):
            p.ldpost(6, 1)
            p.stpost(5, 6)
    p.loop_r(7, 35 // 8, move8)
    for _ in range(35 % 8):
        p.ldpost(6, 1)
        p.stpost(5, 6)


def advance(p: Prog, L: K.Layout) -> None:
    """The stream moves on a block (B[32..66] -> B[0..34]) and the next is rendered at
    OUT0. Clobbers everything but I3, I4. 2026-11-12 (SIMD voice pairs, dnfw.perc.pairs): a voice whose
    move and render were done ahead this block skips them."""
    from ..perc import pairs as PAIRS
    PAIRS.skip_move(p, L, lambda: _move(p, L))
    # v0.24: the host's scale function is emitted once (it was twice: after a note and
    # for dirty words), run when a note waits or, with a machine, when words are dirty
    K.vw(p, 0, "trg")

    def change_if_new():
        new_track(p, L)
        K.vw(p, 0, "want")
        K.vw(p, 1, "mach")
        p.e("COMP(R0, R1);")

        def change():                          # init runs after the host (below)
            # v0.42 (the owner: PI-HH played a rimshot-like note, then loud spikes, with PI-BD
            # and TRX-CP on other tracks, gone with the tracks locked to one voice): the DSP's
            # voices go round the tracks, and a voice that played another machine kept its
            # host words, state, stream and P-I delay lines, under the new machine (a ringing
            # PI-RS's voice handed a TRX-CP note peaked at 1.40, fresh 0.41). A voice changing
            # machine now starts as a fresh one (reset's words, but the voice's own: the read
            # position, the note waiting, the inputs), its delay lines too if the machine it
            # leaves used them (the P-I machines, VO-6)
            K.vw(p, 1, "mach")

            def clear():
                p.ld(0, L.C["mdb"])
                p.seti(5, 0)
                p.iconst(6, 0)
                _zeros(p, K.B0 + K.NB)                          # W, S, the stream

                def lines():
                    K.delay_base(p, L, 0)
                    p.seti(5, 0)
                    p.iconst(6, 0)
                    _zeros(p, L.delay_words)
                K.vw(p, 1, "mach")
                p.iconst(12, DELAY_LO)
                p.iconst(2, 0)
                p.if_(1, "GE", 12, lambda: (p.iconst(12, DELAY_HI),
                                            p.if_(1, "LE", 12, lambda: p.iconst(2, 1), kind="i")), kind="i")
                for k in DELAY_ALSO:
                    p.iconst(12, k)
                    p.if_(1, "EQ", 12, lambda: p.iconst(2, 1), kind="i")
                p.ifz(2, "NE", lines)
            p.ifz(1, "GE", clear)
            K.vw(p, 0, "want")
            K.vws(p, "mach", 0)
            p.iconst(0, 1)
            K.vws(p, "chg", 0)
            for k in INIT_FIRST:               # ... but these machines' before it
                K.vw(p, 0, "mach")
                p.iconst(12, k)

                def first(M=MM.MACHINES[k]):
                    M.init(p, L)               # (its own init only: the chain is emitted once, below)
                    p.iconst(0, 0)
                    K.vws(p, "chg", 0)
                p.if_(0, "EQ", 12, first, kind="i")
        p._branch(lambda: p.r[0] != p.r[1], "NE", change, None)
    p.ifz(0, "NE", change_if_new)
    K.vw(p, 0, "trg")

    def no_trg():                              # R0 = dirty, or 0 with no machine
        K.vw(p, 1, "mach")
        K.vw(p, 0, "dirty")
        p.ifz(1, "LT", lambda: p.iconst(0, 0))
    p.ifz(0, "EQ", no_trg)

    def host():
        _each(p, L, "host")
        p.iconst(0, 0)
        K.vws(p, "dirty", 0)
    # v0.24: a new machine's init after its host scale function, as the Machinedrum (and
    # its golden runs) order them: some inits overwrite a host word (P-IRC's DEC), so
    # init first made the first hit after choosing a machine sound like the second.
    # v0.42: then the host again, so the note plays its knobs: on the DN2 a voice changes
    # machine whenever the voices go round the tracks, so the Machinedrum's "first hit after
    # choosing a machine" (P-I's at DEC 127, the owner's ringing hi-hat) fell on a note in
    # every few; now every note is the machine's own hit at its knobs (the Machinedrum's
    # second hit after a silence). Two passes of the one emitted host (it is 4,666
    # instructions): the second only after an init
    p.st(L.C["hq"], 0)

    def hpass():
        p.ld(0, L.C["hq"])
        p.ifz(0, "NE", host)
        p.iconst(0, 0)
        p.st(L.C["hq"], 0)
        K.vw(p, 0, "chg")

        def init():
            _each(p, L, "init")
            p.iconst(0, 0)
            K.vws(p, "chg", 0)
            p.iconst(0, 1)
            p.st(L.C["hq"], 0)
        p.ifz(0, "NE", init)
    p.loop(L.C["hpass"], 2, hpass)
    K.vw(p, 0, "trg")
    live_turn(p, L)

    def trig():
        _each(p, L, "trig")
        p.iconst(0, 0)
        K.vws(p, "trg", 0)
        K.vws(p, "quiet", 0)
    p.ifz(0, "NE", trig)

    def silent():
        p.ld(1, L.C["mdb"])
        p.iconst(12, 4 * K.OUT0)
        p.iop(1, 12, "+", 1)
        p.seti(5, 1)
        p.fconst(6, 0.0)
        p.loop0(32, lambda: p.stpost(5, 6))

    def sound():
        PAIRS.render(p, L, lambda: _each(p, L, "render"))
        # silent long enough (QUIET_BLOCKS blocks under QUIET_LEVEL): the machine rests
        # until the next note, as its sound has died away (it costs the DSP nothing then)
        p.ld(1, L.C["mdb"])
        p.iconst(12, 4 * K.OUT0)
        p.iop(1, 12, "+", 1)
        p.seti(1, 1)                           # (2026-11-12: I1, not I5: a load rides on a compute)
        p.fconst(7, 0.0)
        peak32(p, 1)
        K.vw(p, 0, "quiet")
        p.fconst(12, QUIET_LEVEL)
        p.if_(7, "LT", 12, lambda: (p.iconst(12, 1), p.iop(0, 12, "+", 0)),
              lambda: p.iconst(0, 0))
        K.vws(p, "quiet", 0)
    K.vw(p, 0, "mach")

    def playing():
        K.vw(p, 0, "quiet")
        p.iconst(12, QUIET_BLOCKS)
        p.if_(0, "GE", 12, silent, sound, kind="i")
    p.ifz(0, "GE", playing, silent)


def live_turn(p: Prog, L: K.Layout) -> None:
    """2026-11-20 (live knobs): VW['live'] = 0 when this voice re-reads its note-start knobs this block: R0 (VW trg)
    nonzero (a trig: the engine's coefficients are worked out after it, in its render), or its turn ((the block
    count - the slot words' address >> 10) & 15 == 0: one slot a block, each every LIVE_EVERY blocks). The same
    instructions every block, whatever the knobs (no idle skip). Keeps R0; clobbers R1, R12."""
    assert K.LIVE_EVERY == 16
    p.ld(1, K.BLOCKS_WORD)
    p.ld(12, L.C["mdb"])
    p.lsh(12, 12, -10)
    p.iop(1, 1, "-", 12)
    p.iconst(12, K.LIVE_EVERY - 1)
    p.iop(1, 1, "AND", 12)
    p.ifz(0, "NE", lambda: p.iconst(1, 0))
    K.vws(p, "live", 1)


def live(p: Prog, coefs) -> None:
    """2026-11-20 (live knobs): COEFS (an engine's knobs -> its words) when VW['live'] says so (live_turn). Clobbers
    R0 before COEFS."""
    K.vw(p, 0, "live")
    p.ifz(0, "EQ", coefs)


def inputs(p: Prog, L: K.Layout, knobs: list[int]) -> None:
    """Step 1: the knob words (scratch addresses KNOBS, floats 0..1) -> the eight 14-bit
    inputs; any change marks the words dirty. 2026-11-12 (opt-host): the four constants held in
    R4, R6-R8 through the eight (the same operations). Clobbers R0-R2, R4, R6-R8, R12."""
    p.fconst(4, 127.0)
    p.fconst(6, 0.5)
    p.iconst(7, 0)
    p.iconst(8, 16383)
    for k, a in enumerate(knobs):
        p.ld(0, a)
        p.fop(0, 0, "*", 4)
        p.fop(0, 0, "+", 6)
        p.trunc(0, 0)
        p.lsh(0, 0, 7)                         # the Machinedrum's knob, 0..127, << 7
        p.iop(0, 0, "MAX", 7)
        p.iop(0, 0, "MIN", 8)
        K.inp(p, 1, k)
        p.e("COMP(R0, R1);")

        def changed(k=k):
            p.sti(K.INP0 + k, 3, 0)
            p.iconst(2, 1)
            K.vws(p, "dirty", 2)
        p._branch(lambda: p.r[0] != p.r[1], "NE", changed, None)


def block(p: Prog, L: K.Layout, knobs: list[int], note: int, want: int, level: float = 1.0,
          level_word: int | None = None, after_advance=None, no_output=None) -> None:
    """One DN2 block (steps 1-4): KNOBS the scratch words of the eight knobs, Rnote nonzero
    for a note, Rwant the machine TYPE asks for (0..N-1). Output from I4 on, written through I2
    (2026-11-12: I2 left past the block, I4 at its start). Clobbers everything but I3. AFTER_ADVANCE (2026-11-11): code run once the stream has
    moved on (the machine VW['mach'] is the one this block plays), before the level is read. NO_OUTPUT (2026-11-15,
    PARA design B): code leaving R0 nonzero when this block's output is not used (no resampling, the position moved
    on as the resampler moves it); it may clobber R0, R6, R7, R12, R13, I1."""
    p.ifz(note, "NE", lambda: (K.vws(p, "want", want), p.iconst(0, 1), K.vws(p, "trg", 0)))
    inputs(p, L, knobs)
    K.vw(p, 0, "pos")
    p.fconst(12, START)
    p.if_(0, "GE", 12, lambda: (advance(p, L), K.vw(p, 0, "pos"), p.fconst(12, 32.0),
                                  p.fop(0, 0, "-", 12), K.vws(p, "pos", 0)))
    if after_advance is not None:
        after_advance()
    if no_output is None:
        _resample(p, L, level, level_word)
        return
    # 2026-11-15 (PARA design B, the User: "Do that"): NO_OUTPUT(p) leaves R0 nonzero for a voice whose output is not
    # used (a PARA chord's member: its caller writes silence): the read position moves on as the resampler moves it
    # (the same 32 adds), nothing is read or written
    no_output(p)
    p.ifz(0, "NE", lambda: _position_only(p), lambda: _resample(p, L, level, level_word))


def _position_only(p: Prog) -> None:
    """the read position moved on a block, as _resample moves it (32 adds of the step, in turn)"""
    K.vw(p, 6, "pos")
    p.fconst(4, K.STEP)
    p.loop_r(5, 32, lambda: p.fop(6, 6, "+", 4))
    K.vws(p, "pos", 6)


def _resample(p: Prog, L: K.Layout, level: float, level_word: int | None) -> None:
    """step 4: the block out (Output from I4 on, written through I2), the read position moved on"""
    # step 4: Catmull-Rom over B[i-1..i+2], i = trunc(pos), f = pos - i
    p.ld(0, L.C["mdb"])
    p.iconst(12, 4 * (K.B0 - 1))
    p.iop(0, 12, "+", 0)
    p.st(L.C["k"], 0)                          # the address of B[-1]
    # v0.42: the read position (R6), B[-1]'s address (R13), the level's two factors (R14,
    # R15) and the count (R5) held in registers through the 32 samples (v0.41 loaded and
    # stored the position, loaded the address and counted in a scratch word every sample):
    # the same operations in the same order, the same words (scripts/md_identity.py)
    K.vw(p, 6, "pos")
    p.ipass(13, 0)
    # 2026-11-21 (multifunction): the level in F4 and the step in F15 (were F15, F4): b x level can then ride on
    # an add as one multifunction instruction (the multiplier's operands are F0-F3 x F4-F7)
    if level_word is None:
        p.fconst(14, 0.5 * level)
        p.fconst(4, level)
    else:                                      # v0.26: the level from a word (x 0.5, then x level:
        p.fconst(14, 0.5)                      # the same product, bit for bit)
        p.ld(4, level_word)

    p.fconst(15, K.STEP)                       # 2026-11-10 (poly16): the step held (F15 since 2026-11-21)
    # 2026-11-12 (opt-host): the same operations on the same values, in an order that lets the four stream
    # loads ride on computes, with 4.0 held in F7 through the 32 samples and the samples written through I2
    # (I0..I3 take a move beside a compute; I4 stays at the block's start): 31 instructions a sample, not 36
    p.fconst(7, 4.0)
    p.geti(9, 4)
    p.seti(2, 9)

    def one():
        p.trunc(9, 6)
        p.lsh(11, 9, 2)
        p.iop(11, 13, "+", 11)
        p.seti(1, 11)
        p.float0(8, 9)                         # (FLOAT R9, as FLOAT R9 BY 0)
        p.ldpost(0, 1)                         # a = B[i-1]
        p.fop(8, 6, "-", 8)                    # f
        p.ldpost(1, 1)                         # b
        # 2026-11-20 (clip-inner; the User: "NO DIGITAL CLIPPING ... if it does, i want the alert"): a stream word the
        # machine's 56300 limiter held (TOP or -1.0 exactly: the Machinedrum's and Monomachine's outputs store through
        # it): the voice's clip (perc.program clip_flag; F12, TOP's or -1.0's bits, the nonzero word)
        from ..perc import program as PP
        p.fconst(12, K.TOP)
        PP.clip_flag(p, 1, "EQ", 12, 12)
        p.fconst(12, -1.0)
        PP.clip_flag(p, 1, "EQ", 12, 12)
        # y = b + f/2 (c - a + f (2a - 5b + 4c - d + f (3(b - c) + d - a)))
        p.fop(10, 0, "+", 0)                   # 2a
        p.ldpost(2, 1)                         # c
        p.fconst(12, 5.0)
        p.fop(12, 1, "*", 12)                  # 5b (in F12: the ALU half below reads F12-F15)
        p.ldpost(3, 1)                         # d
        # 2026-11-21 (multifunction): 4c and the - 5b in one instruction (each reads the values before either
        # writes: the same two operations on the same operands as in turn, bit for bit)
        p.par(("*", 11, 2, 7), ("-", 10, 10, 12))   # F11 = 4c || F10 = 2a - 5b
        p.fop(10, 10, "+", 11)                 # + 4c
        p.fop(10, 10, "-", 3)                  # - d
        p.fop(9, 1, "-", 2)
        p.fconst(12, 3.0)
        p.fop(9, 9, "*", 12)
        p.fop(9, 9, "+", 3)
        p.fop(9, 9, "-", 0)                    # 3(b - c) + d - a
        p.fop(9, 9, "*", 8)
        p.fop(9, 9, "+", 10)
        p.fop(9, 9, "*", 8)
        p.fop(12, 2, "-", 0)                   # c - a (in F12)
        # 2026-11-21 (multifunction): b x level (was after the products below; its operands do not change) and
        # the + (c - a) in one instruction
        p.par(("*", 10, 1, 4), ("+", 9, 9, 12))     # F10 = b level || F9 = f(...) + (c - a)
        p.fop(9, 9, "*", 8)
        p.fop(9, 9, "*", 14)
        if level_word is not None:
            p.fop(9, 9, "*", 4)
        p.fop(9, 9, "+", 10)
        p.fop(6, 6, "+", 15)                   # the position on
        p.stpost(2, 9)                         # the sample out (with the add above: one instruction)
    p.loop_r(5, 32, one)
    K.vws(p, "pos", 6)
    p.st(L.C["n1"], 5)
