"""P-IML: the Machinedrum's mallet (a physical model; docs/md.md), from DSP2's P-IML and
its host scale function.

A block: the mallet's excitation (a ROM recording, read at a pitch-dependent rate with
linear interpolation) times HARD, through a one-pole lowpass, drives eight two-pole modes
(frequencies from PTCH and the TENS envelope, radii from DEC through the decay curve);
the modes are summed onto the excitation's first sample, under a per-block amplitude
envelope.

Exactness. Everything but the modes is the 56300's arithmetic on integer words, exactly:
`xmul` is a 24 x 24-bit product (or the sum of two) floored at bit s, from 12-bit halves
whose float products are exact; the lowpass (coefficient $7FFFAC, a 48-bit accumulator)
is integer arithmetic on its word and fraction. The coefficients that set each mode's
pole are exact words, so a mode rings at the Machinedrum's frequency. The modes' 48-bit
states are floats (Q23): their rounding is far below the 24-bit output.

Quirks kept: init sets word 3 (HARD) to 0 after the host's words, so the first note after
the machine is chosen is silent on the Machinedrum. Not kept on the DN2: the voice runs
this machine's init before the host's words (INIT_FIRST; every other machine's after, as
the MD does), so that note plays, as the MD's second would. The excitation's step 6 pass, as the firmware has it,
leaves only the block's first excited sample in the sum (its state words Y24, Y25 stay 0);
the three per-block decays at Y28..Y30 are never read and are left out.
"""

from __future__ import annotations

from . import core as K
from .core import inp, s, ss, w, ws
from .gnd import pitch_word
from ..perc.dsl import Prog

Q = K.Q23
TBASE = 0x143F38                  # PIML_T's first word: the mode tables, then the excitation
EXC0 = 0x143F50 - TBASE           # where a note starts reading
EXC_END = 0x1449C9 - TBASE        # where the stored pointer stops
Y8_LP = 0x7FFFAC                  # the lowpass coefficient (init): 1 - 84 / 2^23
Y9 = 0x7FDF3B                     # the decay index's scale (init)
MAXW, MINW = 0x7FFFFF, -0x800000


# -- exact integer helpers (shared with pi_ma) ------------------------------------------------
def _xmul_body(p: Prog, sh: int, two: bool, rne: bool) -> None:
    """R2 = floor((R4 R5 [+ R6 R7] + R3) / 2^sh) (signed 24-bit words; |R3| < 2^25), or
    with RNE the 56300's convergent rounding of it (R3 = 2^(sh-1)). Clobbers R0, R1,
    R8-R15.

    perf, 2026-11-11: on the fixed-point multiplier. A product is q 2^sh + r: q = floor(A B / 2^sh) by SSF on
    A 2^7 and B 2^(24 - sh) (both stay 32-bit words for |A|, |B| < 2^24), r = the low word's low sh bits by SSI; the sum is
    q1 (+ q2) + floor((r1 (+ r2) + K) / 2^sh), exactly what the 12-bit halves gave. A tie (the low sh bits of
    the sum + K all zero) goes to the even word."""
    mask = (1 << sh) - 1

    def prod(a: int, b: int, q: int, r: int) -> None:
        p.lsh(0, a, 7)                        # |A| < 2^24 (a difference of two words is that wide)
        p.lsh(1, b, 24 - sh)
        p.mul_ssf(q, 0, 1)
        p.mul_ssi(r, a, b)
        p.iconst(12, mask)
        p.iop(r, r, "AND", 12)
    prod(4, 5, 2, 8)
    if two:
        prod(6, 7, 9, 10)
        p.iop(8, 8, "+", 10)
        p.iop(2, 9, "+", 2)
    p.iop(8, 8, "+", 3)                       # r (+ r') + K
    if rne:
        p.iconst(12, mask)
        p.iop(11, 8, "AND", 12)               # zero: a tie
    p.ash(8, 8, -sh)
    p.iop(2, 8, "+", 2)
    if rne:
        p.ifz(11, "EQ", lambda: (p.iconst(12, -2), p.iop(2, 2, "AND", 12)))


def xmul(p: Prog, sh: int = 23, two: bool = False, rne: bool = False) -> None:
    """R2 = _xmul_body(...) through one shared copy (a leaf subroutine). Clobbers R0, R1,
    R2, R8-R15, I12; keeps R3-R7."""
    name = f"pi_x{sh}{'d' if two else ''}{'r' if rne else ''}"
    p.call(name, lambda: _xmul_body(p, sh, two, rne))


def clamp(p: Prog, r: int, lo: int = MINW, hi: int = MAXW) -> None:
    """Rr = the 56300 limiter on an integer word. Clobbers R12."""
    p.iconst(12, hi)
    p.iop(r, r, "MIN", 12)
    p.iconst(12, lo)
    p.iop(r, r, "MAX", 12)


def to_word(p: Prog, d: int, a: int) -> None:
    """Rd = the Q23 float Fa as its integer word. Clobbers R12."""
    K.mul_k(p, d, a, 2.0 ** 23)
    p.trunc(d, d)


# (opt-md, 2026-11-12) floor23's constants and the limiter's bounds, where a loop holds them in registers
F_ONE, F_M23, F_TOP, F_M1, F_P23 = 1, 2, 3, 4, 15


def consts(p: Prog) -> None:
    """F1 = 1, F2 = 2^-23, F3 = TOP, F4 = -1, F15 = 2^23 (floor23r's and satr's)."""
    p.fconst(F_ONE, 1.0)
    p.fconst(F_M23, 2.0 ** -23)
    p.fconst(F_TOP, K.TOP)
    p.fconst(F_M1, -1.0)
    p.fconst(F_P23, 2.0 ** 23)


def satr(p: Prog, x: int) -> None:
    """K.sat with the bounds in F3, F4 (consts)."""
    p.fop(x, x, "MIN", F_TOP)
    p.fop(x, x, "MAX", F_M1)


def floor23r(p: Prog, d: int, a: int, t: int, u: int) -> None:
    """floor23 with its constants in registers (consts) and no jump: d = float(trunc(u)), one less
    where d > u (the flags of d - u: a float difference is 0 only where the two are equal, and has
    the exact difference's sign), then d 2^-23 (exact). Clobbers Rt, Ru (d may be a)."""
    p.fop(u, a, "*", F_P23)
    p.trunc(t, u)
    p.float0(d, t)
    p.fop(t, d, "-", u)
    p.fop_if("GT", d, d, "-", F_ONE)
    p.fop(d, d, "*", F_M23)


def floor23(p: Prog, d: int, a: int, t: int, u: int) -> None:
    """Fd = Fa floored to the Q23 grid (either sign). Clobbers R12, Rt, Ru (d may be a)."""
    K.mul_k(p, u, a, 2.0 ** 23)
    p.trunc(t, u)
    p.iconst(12, 0)
    p.float_(d, t, 12)
    p.if_(d, "GT", u, lambda: (p.iconst(12, -1), p.iop(t, 12, "+", t)))
    p.iconst(12, -23)
    p.float_(d, t, 12)


# =====================================================================================
class PIML:
    """P-IML (md_models-style integer model in ../md163/research/emu56k: PI_NOTES.md).
    Words (integers, 24-bit): W1 pitch, W2 the amplitude's decay a block, W3 = W7 HARD,
    W4 DEC << 9, W5 TENS depth, W6 TENS decay a block.
    State: the excitation pointer (word, fraction), the TENS envelope, the lowpass's word,
    the amplitude envelope (ints); per-block temps; the modes' (a, x1) and (k2, k1, g);
    the block's lowpassed excitation."""
    NAME, ID = "PI-ML", 67
    # v0.24: the voice runs this machine's init before its host words (the others' after,
    # as the Machinedrum does): the MD's own order leaves its first note silent (HARD 0)
    INIT_FIRST = True
    PNAMES = ("PTCH", "DEC", "HARD", "TENS", "-", "-", "-", "-")
    PI, PF, TENV, LP, AMP, XI, XF, FE, LPF, H0, CS, E8, CC, AW = range(14)
    RES = 16                       # 8 x (a, x1), floats
    COEF = 32                      # 8 x (k2, k1, g), floats
    LPB = 56                       # 32 floats

    @staticmethod
    def host(p: Prog, L: K.Layout) -> None:
        inp(p, 0, 0)                                    # PTCH
        p.lsh(0, 0, -6)
        pitch_word(p, L, 4, 0, 10)
        p.trunc(4, 4)
        p.iconst(12, -1000)
        p.iop(4, 12, "+", 4)
        ws(p, 1, 4)
        inp(p, 0, 1)                                    # DEC
        p.lsh(1, 0, -7)
        p.iconst(12, 280)
        p.iop(1, 12, "+", 1)
        K.table_f(p, L, 4, "hostQ", 1)
        to_word(p, 4, 4)
        ws(p, 2, 4)
        p.lsh(4, 0, 9)
        ws(p, 4, 4)
        inp(p, 0, 2)                                    # HARD: in 400 + 1000000
        p.iconst(12, 0)
        p.float_(4, 0, 12)
        K.mul_k(p, 4, 4, 400.0)
        K.add_k(p, 4, 4, 1000000.0)
        p.trunc(4, 4)
        ws(p, 3, 4)
        ws(p, 7, 4)
        inp(p, 0, 3)                                    # TENS

        def low():
            p.lsh(4, 0, 9)
            ws(p, 5, 4)
            p.iconst(1, 300)
            K.table_f(p, L, 4, "hostQ", 1)
            to_word(p, 4, 4)
            ws(p, 6, 4)

        def high():
            p.iconst(4, 0x400200)
            ws(p, 5, 4)
            p.iconst(12, -8192)
            p.iop(1, 12, "+", 0)
            p.lsh(1, 1, -7)
            p.iconst(12, 300)
            p.iop(1, 12, "+", 1)
            K.table_f(p, L, 4, "hostQ", 1)
            to_word(p, 4, 4)
            ws(p, 6, 4)
        p.iconst(12, 8191)
        p.if_(0, "LE", 12, low, high, kind="i")

    @staticmethod
    def init(p: Prog, L: K.Layout) -> None:
        M = PIML
        p.iconst(0, 0)
        ws(p, 3, 0)                                     # HARD = 0 (the firmware's quirk)
        ss(p, M.LP, 0)
        K.zero_words(p, M.RES, 16)                      # (2026-11-20: a loop, perc2b's room)

    @staticmethod
    def trig(p: Prog, L: K.Layout) -> None:
        M = PIML
        p.iconst(0, EXC0)
        ss(p, M.PI, 0)
        p.iconst(0, 0)
        ss(p, M.PF, 0)
        p.iconst(0, 0x7FFFAC)
        ss(p, M.TENV, 0)
        ss(p, M.AMP, 0)

    @staticmethod
    def render(p: Prog, L: K.Layout) -> None:
        M, C = PIML, L.C
        T = L.T["PIML_T"]
        # -- the block's increment and frequency scale (TENS's envelope) ------------------
        p.iconst(3, 0)
        s(p, 7, M.TENV)
        w(p, 4, 6)
        p.ipass(5, 7)
        xmul(p)                                         # env *= W6
        ss(p, M.TENV, 2)
        w(p, 4, 5)
        p.ipass(5, 7)
        xmul(p)
        p.iconst(12, 0x400000)
        p.iop(5, 12, "+", 2)
        clamp(p, 5)                                     # y0 = 0.5 + W5 env
        w(p, 4, 1)
        xmul(p, 20)                                     # X = W1 y0 >> 20 (48-bit increment)
        p.lsh(0, 2, -24)
        ss(p, M.XI, 0)
        p.iconst(12, 0xFFFFFF)
        p.iop(0, 2, "AND", 12)
        ss(p, M.XF, 0)
        p.lsh(0, 2, -2)
        clamp(p, 0)
        ss(p, M.FE, 0)                                  # Y:$FE
        # -- the excitation: read, HARD, lowpass ------------------------------------------
        p.iconst(0, 0)
        ss(p, M.LPF, 0)
        p.ld(0, C["mdb"])
        p.iconst(12, 4 * (K.S0 + M.LPB))
        p.iop(0, 12, "+", 0)
        p.seti(5, 0)

        def sample():
            s(p, 9, M.PF)
            s(p, 10, M.XF)
            p.iop(9, 9, "+", 10)
            p.lsh(10, 9, -24)                           # the carry
            p.iconst(12, 0xFFFFFF)
            p.iop(9, 9, "AND", 12)
            ss(p, M.PF, 9)
            s(p, 11, M.PI)
            s(p, 13, M.XI)
            p.iop(11, 11, "+", 13)
            p.iop(11, 11, "+", 10)
            ss(p, M.PI, 11)
            p.lsh(11, 11, 2)
            p.iconst(12, T)
            p.iop(11, 12, "+", 11)
            p.seti(1, 11)
            p.ldi(6, 0, 1)
            p.ldi(7, 1, 1)
            to_word(p, 6, 6)                            # T0
            to_word(p, 7, 7)                            # T1
            p.iop(4, 7, "-", 6)                         # T1 - T0
            p.ipass(5, 9)                               # f
            p.iconst(12, 0)
            p.iop(3, 12, "-", 6)                        # - T0
            xmul(p)
            p.lsh(6, 6, 1)
            p.ipass(8, 2)
            p.iop(4, 8, "+", 6)                         # V = 2 T0 + (D f - T0) >> 23
            clamp(p, 4)
            w(p, 5, 3)
            p.iconst(3, 0)
            xmul(p, 22)                                 # H = sat(2 mpy(V, HARD))
            clamp(p, 2)
            p.ld(0, C["n2"])
            p.iconst(12, 32)
            p.if_(0, "EQ", 12, lambda: ss(p, M.H0, 2), kind="i")
            # the lowpass, exactly: A = S 2^24 + F; A += 2 Y8 (H - S)
            s(p, 13, M.LP)
            p.iconst(12, -23)
            p.float_(4, 13, 12)
            p.stpost(5, 4)                              # the output: S before the sample
            p.iop(8, 2, "-", 13)                        # D
            p.lsh(9, 8, 4)
            p.lsh(10, 8, 2)
            p.iop(9, 9, "+", 10)
            p.iop(9, 9, "+", 8)                         # 21 D
            s(p, 10, M.LPF)
            p.iconst(12, 7)
            p.iop(14, 10, "AND", 12)                    # Fl
            p.lsh(10, 10, -3)                           # Fh
            p.iop(11, 10, "-", 9)                       # t = Fh - 21 D
            p.ash(13, 11, -21)
            p.iop(13, 13, "+", 2)
            ss(p, M.LP, 13)                             # S = H + (t >> 21)
            p.iconst(12, 0x1FFFFF)
            p.iop(11, 11, "AND", 12)
            p.lsh(11, 11, 3)
            p.iop(11, 11, "OR", 14)
            ss(p, M.LPF, 11)
        p.loop(C["n2"], 32, sample)
        s(p, 0, M.PI)                                   # the stored pointer stops at $1449C9
        p.iconst(12, EXC_END)

        def stop():
            p.iconst(0, EXC_END)
            ss(p, M.PI, 0)
            p.iconst(0, 0)
            ss(p, M.PF, 0)
        p.if_(0, "GE", 12, stop, kind="i")

        # -- the modes' coefficients ------------------------------------------------------
        def tword(d, k):
            p.ld(d, T + 4 * k)
            to_word(p, d, d)
        for i in range(8):
            p.iconst(3, 0)
            tword(4, i)
            s(p, 5, M.FE)
            xmul(p)                                     # w = T38 fe
            p.ipass(5, 2)
            p.iconst(12, 0)
            p.iop(4, 12, "-", 2)
            p.ipass(6, 4)                               # -w
            p.ipass(7, 5)                               # w
            xmul(p)                                     # y1 = floor(-w^2)
            p.ipass(4, 2)
            p.iconst(5, 0x155555)
            xmul(p)                                     # y1b = y1 / 6
            p.ipass(5, 4)
            p.ipass(4, 2)
            xmul(p, two=True)                           # y1b y1 - w^2
            p.iconst(12, MAXW)
            p.iop(2, 12, "+", 2)
            clamp(p, 2)
            ss(p, M.CS, 2)                              # cs: 1 - w^2 + w^4 / 6
            tword(4, 16 + i)
            w(p, 5, 7)
            xmul(p)
            ss(p, M.E8, 2)                              # e8 = T48 HARD
            tword(4, 8 + i)
            w(p, 5, 4)
            xmul(p)                                     # e0 = T40 DEC
            p.ipass(4, 2)
            p.iconst(5, Y9)
            xmul(p)                                     # the curve's index
            clamp(p, 2, 0, 511)
            K.table_f(p, L, 4, "PI_CURVE_142949", 2)
            to_word(p, 4, 4)
            ss(p, M.CC, 4)                              # c
            s(p, 5, M.CS)
            xmul(p, 22)
            p.iconst(12, -0x800000)
            p.iop(2, 12, "+", 2)
            clamp(p, 2)
            p.iconst(12, -23)
            p.float_(0, 2, 12)
            ss(p, M.COEF + 3 * i + 1, 0)                # k1 = 2 c cs - 1
            s(p, 4, M.CC)
            p.iconst(12, 0)
            p.iop(6, 12, "-", 4)
            p.ipass(7, 4)
            p.ipass(5, 4)
            p.ipass(4, 6)
            xmul(p)
            clamp(p, 2)
            p.iconst(12, -23)
            p.float_(0, 2, 12)
            ss(p, M.COEF + 3 * i, 0)                    # k2 = -c^2
            s(p, 4, M.CC)
            s(p, 5, M.CS)
            p.lsh(5, 5, 1)
            xmul(p, two=True)                           # 2 c cs - c^2
            p.iconst(12, -0x800000)
            p.iop(2, 12, "+", 2)
            clamp(p, 2)
            p.ipass(5, 2)
            s(p, 4, M.E8)
            xmul(p, 22)
            clamp(p, 2)
            p.iconst(12, -23)
            p.float_(0, 2, 12)
            ss(p, M.COEF + 3 * i + 2, 0)                # g = 2 e8 (2 c cs - 1 - c^2)

        # -- the sum: the excitation's first sample, then each mode on top ---------------
        p.ld(0, C["mdb"])
        p.iconst(12, 4 * K.OUT0)
        p.iop(0, 12, "+", 0)
        p.seti(5, 0)
        s(p, 1, M.H0)
        p.iconst(12, -23)
        p.float_(1, 1, 12)
        p.stpost(5, 1)
        p.fconst(1, 0.0)
        p.loop0(31, lambda: p.stpost(5, 1))
        for i in range(8):
            # (opt-md, 2026-11-12) the mode on the multiplier || ALU (PI-SD's form), in a hardware loop: the same
            # operations on the same operands in the same order. F4..F6 k2, k1, g; F1 x1, F2 xw, F3 x; F8 a; the
            # products in F12..F14; F7 2^23, F9 2^-23, F11 1, F15 TOP, F0 -1 (floor23r's and the limiter's)
            s(p, 4, M.COEF + 3 * i)
            s(p, 5, M.COEF + 3 * i + 1)
            s(p, 6, M.COEF + 3 * i + 2)
            s(p, 8, M.RES + 2 * i)                      # a (48-bit, a float)
            s(p, 1, M.RES + 2 * i + 1)                  # x1: the word before
            floor23(p, 2, 8, 13, 14)                    # xw: a's word (stored limited)
            K.sat(p, 2)
            p.ld(0, C["mdb"])
            p.iconst(12, 4 * (K.S0 + M.LPB))
            p.iop(3, 12, "+", 0)
            p.seti(0, 3)                                # (I0: a compute's move reaches I0..I3 only)
            p.iconst(12, 4 * K.OUT0)
            p.iop(3, 12, "+", 0)
            p.seti(2, 3)
            p.fconst(7, 2.0 ** 23)
            p.fconst(9, 2.0 ** -23)
            p.fconst(11, 1.0)
            p.fconst(15, K.TOP)
            p.fconst(0, -1.0)

            def pad():                                  # a harmless read (F3 is dead until the next x): the
                p.ldi(3, 0, 0)                          # loop's last 11 instructions must be 48-bit (hwrules)

            def mode():
                p.par(("*", 12, 1, 4), ("ld", 3, 0))    # p1 = x1 k2; x
                p.par(("*", 13, 2, 5), ("+", 8, 8, 12))  # p2 = xw k1; a + p1
                p.par(("*", 14, 3, 6), ("+", 8, 8, 13))  # p3 = x g; + p2
                p.fpass(1, 2)                           # x1 = xw (limited)
                p.fop(8, 8, "+", 14)                    # + p3
                p.fop(10, 8, "*", 7)                    # floor23r (F10 u, R13 t), into F2
                pad()
                p.trunc(13, 10)
                pad()
                p.float0(2, 13)
                pad()
                p.fop(13, 2, "-", 10)
                pad()                                   # (a move on the subtract leaves its flags to the IF)
                p.fop_if("GT", 2, 2, "-", 11)
                p.fop(2, 2, "*", 9)                     # a's word, before the limiter
                p.ldi(14, 0, 2)
                p.fop(14, 14, "+", 2)
                pad()
                p.fop(14, 14, "MIN", 15)
                pad()
                p.fop(14, 14, "MAX", 0)
                pad()
                p.stpost(2, 14)                         # (on the next instruction)
                p.fop(2, 2, "MIN", 15)                  # x1 takes it through the limiter
                p.fop(2, 2, "MAX", 0)
                pad()
            p.loop_hw(32, mode, cnt=12)
            p.fpass(9, 1)                               # (x1 where the code below keeps it)
            # stored as the firmware stores it: A1 through the limiter, A0 as it is
            floor23(p, 11, 8, 13, 14)
            p.fop(13, 8, "-", 11)                       # A0
            K.sat(p, 11)
            p.fop(8, 11, "+", 13)
            ss(p, M.RES + 2 * i, 8)
            ss(p, M.RES + 2 * i + 1, 9)

        # -- the amplitude: floor(env / 2), env *= W2 a block -------------------------------
        s(p, 5, M.AMP)
        w(p, 4, 2)
        p.iconst(3, 0)
        xmul(p)
        ss(p, M.AMP, 2)
        p.lsh(5, 5, -1)
        p.iconst(12, -23)
        p.float_(5, 5, 12)
        p.ld(0, C["mdb"])
        p.iconst(12, 4 * K.OUT0)
        p.iop(1, 12, "+", 0)
        p.seti(2, 1)

        consts(p)

        def out():
            p.ldi(6, 0, 2)
            p.fop(6, 6, "*", 5)
            floor23r(p, 6, 6, 13, 14)
            p.stpost(2, 6)
        p.loop0(32, out)


MACHINES = (PIML,)
